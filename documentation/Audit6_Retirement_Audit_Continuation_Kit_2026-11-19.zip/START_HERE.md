# Audit6 Retirement Audit Continuation — new-conversation handoff

**Prepared:** November 19, 2026 (America/Phoenix)
**Purpose:** Carry forward the accepted code, user decisions, scenario inputs, test evidence, and exact provenance when starting a new audit conversation. **This packet is not a new audit and does not claim the current software was retested today.**

## Use in the next conversation

1. Create a **new chat inside the existing `sw development` project** and name it `Audit6 Retirement Audit Continuation` (the earlier Audit4 and Audit5 phases are already closed). ChatGPT cannot create or rename the conversation from the prior chat.
2. Upload `Audit6_Retirement_Audit_Continuation_Kit_2026-11-19.zip` to that chat. Upload any future modified Java source separately so that the model can tell which file is the proposed revision.
3. Paste the companion `Audit6_New_Chat_Kickoff.txt` into the new chat. Ask the model to first inventory attachments and verify SHA-256 of the accepted source before doing any code comparison.
4. If there is no new source yet, ask only for a coverage review or discussion. Do not invent a new failure or run redundant acceptance tests automatically.

## Canonical accepted baseline

- **Accepted source:** `source/accepted/RiskBased_OptSocSec_v2(2).java` (original uploaded filename retained); Java package `com.hiflite.riskbased_optsocsec`, public class `RiskBased_OptSocSec_v2`.
- **Source header:** `Last modified: Wednesday, November 18, 2026 at 5:47 PM MST (UTC-7)` (also `BUILD_STAMP`).
- **SHA-256:** `10e4d12868f82621aab84fa831e111d5c31dfe67f25afc3f106a04da9725a783`.
- **Prior pre-fix source for diff only:** `source/baselines/RiskBased_OptSocSec_v2(1).java`, SHA-256 `136e864b7d0925023567dc94c3453e5340892e1015c937a0919b6bc35507626f`.
- **Latest disposition:** Audit5 post-fix was **CLOSED / ACCEPTED WITH DOCUMENTED LIMITATIONS**, on November 19, 2026. This supersedes any older Audit5 status described in the first part of Register v0.3 or the November 18 conditional review. The revised 2027 LTCG bands now select by active tax-base year; a tax-year mismatch indicator is visible.
- **Audit5 post-fix execution:** 302 asserted checks passed, 0 failures (the archive also includes a clean-extraction re-run with 211 targeted checks). This is scoped software acceptance, **not an independent verification of official 2027 statutory tax figures**.
- **Known qualification:** The exact cause of one earlier standalone Monte Carlo mismatch remains *unverified*. Controlled one/four-thread tests and four stabilized full-fidelity runs matched; preserve outlier logs and test for repeatability when changing loader/concurrency logic.

## Primary saved inputs and a crucial tax-year caveat

- `scenarios/2026-11-16_near_1_9M_mult_16_13_great_candidate.ilscen` is the current primary regression scenario. It was saved November 17, 2026. Its simulation starts in **2027**; account sum is approximately $1.9 million; it specifies 31 years, **1,200 solve paths, 600 fan paths, 25 binary iterations**, go-go **1.6**, slow-go **1.3**, 5.5% nominal return and 10.79% SD, initial external savings $100,000, `mm.coversEarly=false`, and *no brokerage sale*. There is no `tax.thresholdYear` key in this file, so its legacy thresholds load as **2026**. Do **not** silently claim that this is a 2027-tax-set result.
- `scenarios/2026-11-05_near_2M_mult_17_13_great_candidate.ilscen` is an earlier regression input, 1.7 go-go and 1.3 slow-go.
- For a 2027 tax-set comparison, **explicitly** choose `Reset to 2027` in the UI or create a clearly named derivative and report the active tax year. Do not overwrite the user's original scenario.
- The screenshot may show **early savings coverage ON** even though the input file has it OFF. Test both explicitly and never assume screenshot settings were saved to the file.
- For fixed-seed comparisons, uncheck `Re-randomize each run` or supply exactly the same seed to direct `simulatePro` calls. For the actual GUI, `Run Simulation` with randomization off uses seed zero; deterministic tests should state all inputs and seed.

## Previous accepted audit phases

| Stage | Source/review | Tests and acceptance |
|---|---|---|
| Audit3 | `reviews/Audit3_Final_Coverage_Acceptance_Review.md` | 316 passing, 0 failing; accepted with limitations, November 2. Brokerage sale tax in partial years, taxes/IRMAA, cash reserves, RMD/survivor, optimizer/GUI. |
| Audit4 | `reviews/Audit4_Final_Coverage_Acceptance_Review.md` | 434 passing, 0 failing; accepted with limitations, November 14. Two cash pools, Roth conversion funding, already-claimed SS, optimizer fingerprints, GUI and persistence. |
| Audit5 first pass | `reviews/Audit5_Nov18_Review.md` | 255 passing, 0 failing, conditional due to 2027 LTCG bands and old-file tax-year visibility. **Historical only**. |
| Audit5 post-fix | `reviews/Audit5_PostFix_Review.md` | 302 passing, 0 failing; **accepted with limitations**, November 19. 2027 LTCG and mismatch-warning changes passed. This is the **most recent** acceptance. |

Counts across different stages are **not** a single count of independent assertions; many cover overlapping logic and different source revisions. They must not be blindly added as if all were performed on the latest code.

## Primary design-policy authority

`Retirement_Simulator_Design_Decisions_and_Accepted_Limitations_Register_v0.3.md` lists **DDR-001 through DDR-035**, with rationales, evidence quality, conversation provenance catalog (without fabricated chat URLs), and corresponding test-log references. Consult this **before** labeling surprising behavior as a bug. Selected nonnegotiable baseline decisions unless the user explicitly reopens them:

- **DDR-001–003:** Plan rerun at least annually. Surplus intentionally *not* reinvested: discretionary travel/other spending, manually saved if desired. External expenses including medical coverage may be paid out-of-model; the user is responsible for accounting for these.
- **DDR-004–007:** The 80% PoS target applies to the fixed-withdrawal **inner solver**; outer stochastic paths **re-solve annually**. Actual PoS is **portfolio-only**; reserve-assisted completion is an additional, different metric; an annual short year and total lifetime exhaustion are distinct.
- **DDR-008–009:** Final-five-years top-up and the normal withdrawal cap are different controls; portfolio/reserve funds may close late gaps even if a capped annual withdrawal does not.
- **DDR-010–011:** Go-go/slow-go multiply portfolio withdrawals rather than total household income; high initial draw includes an intentional SS bridge.
- **DDR-012–017:** Regular savings is primarily protected for sequence-of-return risk; optional early short-year coverage is off by default. **SS Optimizer always ignores early savings coverage**, even if Pro UI has it on. The holding account for brokerage-sale proceeds may pay conversion tax only when explicitly enabled. Regular savings are spent before holding cash for ordinary shortfalls. Cash interest approximates inflation, including year one.
- **DDR-018–022:** Delaying SS and bridging the gap is deliberate. The bridge tax gross-up is a **performance-conscious approximation**, not a demand for a second full tax simulation. Annual chronology, prior December 31 RMD bases, January withdrawals, December conversions, survivor switches/SS/RMD are deliberate.
- **DDR-023–029:** Roth conversion objective includes widow/survivor and beneficiary tax, not just minimum cumulative in-plan tax. User-selected IRMAA/bracket ceilings supersede the original fixed $40k cap. Conversion tax assumes living income consumed standard deductions even where an exact low-income result might differ; user **accepted** this limitation. Default conversion tax comes from gross; brokerage cash payer is opt-in. Tax-effect UI is cumulative *modeled* tax difference, not NPV or full after-tax inheritance. Taxes are hidden before withdrawal begins, but MAGI/IRMAA lookback remains effective.
- **DDR-030–035:** Brokerage account is **not** fully modeled: one-year sale/cash transfer, long-term gain, $3,000 annual capital-loss ordinary offset and no carryforward. Full sale-related tax (including NIIT) is **not prorated** just because withdrawals start July/December. Inflation draws are floored at zero and shifted to preserve target mean; GK is illustrative; Pro PoS authoritative. Optimizer uses deterministic comparison and invalidates stale cache with relevant changes.

Where precise implementation facts matter, inspect the **source** and direct test logs; this summary is not a substitute for reading the 35 full records. Accepted design choices are requirements, not evidence that all implementations are correct.

## Audit protocol for the NEXT modified source

1. Identify exactly **which file** is new; compare its SHA and textual diff against the November 18 5:47 PM accepted source; verify source header and `BUILD_STAMP` agree. Document changed methods/inputs, persistence keys, fingerprints, source-defined calculations and intended behavior.
2. Compile under available JDK (Java 21 or 25). Review new compiler/lint warnings against previous baseline; do not treat existing warnings as regressions without evidence.
3. Credit earlier executed tests where code and inputs are unchanged, but perform actual **dynamic** tests covering every changed financial pathway and boundary. Independently calculate financial boundaries where feasible; do not solely assert new source equals itself.
4. Preserve first-year January/July/December brokerage sale/NIIT, year-specific 2026/2027 LTCG and tax tables, Roth conversion fills/caps/IRMAA/forced RMD and survivor interactions. Where applicable test explicit 2026 versus 2027 tax-set selection and legacy scenario load.
5. Check proper reserve ordering, partial/complete exhaustion, cash conversion-tax payer, IRMAA lookback and full sale-year tax in partial years. Keep **portfolio-only Actual PoS** separate from reserve-supported outcomes.
6. Run real Swing operational tests under a virtual display (`xvfb-run` where available): startup, load/save/reload, Scenario card tax-year warning and date resets, Pro Run & conversion comparison, optimizer batch/fingerprint, tooltips/layout where changed.
7. Compare fixed-seed **one-thread/four-thread** results and repeat independent processes when new code touches Swing initialization or concurrency. Use an input loader that has fully completed initialization before reading inputs; do not guess the root cause of historical anomalous hash.
8. Use the provided full-fidelity 31-year scenario **1,200/600/25** for final changed-path acceptance where reasonable. Distinguish early-coverage ON/OFF and legacy 2026/selected 2027 tax sets. Record exact seeds and all key inputs.
9. Supply reproducible source snapshots, harnesses, logs, ZIP and explicit pass/fail/qualified disposition. No unexecuted tests presented as passed. Update DDR register only for newly accepted decisions or verified defect closure. Preserve any unresolved finding rather than calling it a design limitation.
10. If no new code is supplied, do **not** manufacture an audit; wait for a specific request to review, test, or update documents.

## Open qualifications and provenance cautions

- **2027 LTCG statutory values:** Post-fix source-defined test passed. The official IRS source values were **not independently verified** during the document-only Audit5. Do not describe those values as independently certified without external verification authorized by the user.
- **Historical isolated full-fidelity mismatch:** An earlier standalone process produced a different hash; same-process thread parity and stabilized-loader repeats matched. Cause **[Unverified]**; preserve evidence, investigate if reproduced.
- **Historical handoff is not current authority:** `riskbased-probofsuccess-handoff-2026-10-30.md` was updated through Nov 18 9:34 AM; its §5 “Open findings” includes issues now fixed as Q44/Q45, and other suggestions not necessarily authorized as changes. Consult accepted new source and the post-fix review.
- **Register v0.3 acceptance-history table is stale:** Its opening Audit5 row predates the post-fix acceptance. Later appendix (Nov 19) and `Audit5_PostFix_Review.md` supersede it. Future editors should update that historical row explicitly if issuing v0.4.
- **Conversation URLs:** Exact original ChatGPT chat permalinks were not retrievable. DDR v0.3 maps known chat titles/phases to a provenance catalog without inventing direct URLs. ChatGPT memory is not a complete durable verbatim audit transcript.

## File map

- `source/accepted/` accepted November 18 5:47 PM Java; `source/baselines/` historical comparison build.
- `scenarios/` primary Nov 16 and secondary Nov 5 `.ilscen` inputs.
- `Retirement_Simulator_Design_Decisions_and_Accepted_Limitations_Register_v0.3.md` — complete DDR register.
- `reviews/` four authoritative audit reviews; `riskbased-probofsuccess-handoff-2026-10-30.md` historical dated developer change log.
- `audit3/` and root `Audit4_*.zip`, `Audit5_*.zip` — executed test archives referred to by the register. Use ZIP internal paths, not just review prose.
- `MANIFEST_SHA256.txt` verifies packet file identity; `Audit6_New_Chat_Kickoff.txt` is a compact, ready-to-paste start message.
