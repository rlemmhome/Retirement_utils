# Audit3 — Final Coverage and Acceptance Review

**Review date:** November 2, 2026 (MST)  
**Disposition:** **ACCEPTED WITH DOCUMENTED LIMITATIONS**  
**Accepted source:** `RiskBased_OptSocSec_v2 (5).java`, header: "Last modified: Monday, November 02, 2026 at 08:48 PM MST (UTC-7)"  
**Source SHA-256:** `be7e99d64704f58af22302209f0a1754dc07659d5a80d00d2e2fecdb45a71dea`

## Decision

The complete Audit3 change set is accepted for its specified behavior, with no outstanding known financial or operational defects. This is a regression and integration acceptance judgment, not a claim of exhaustive verification of every conceivable plan or independent certification of tax-law accuracy.

The source used in both final acceptance packages was byte-for-byte identical to the attached source above; hash comparison verified this.

## Reconciled execution evidence

| Area | Passing checks | Evidence and result excerpt |
|---|---:|---|
| Original vs. revised financial scenarios and partial-year sale tax | 115 | `revision5/acceptance_115_checks.log`: `SUMMARY: 115 checks; 0 failures` |
| Prior-MAGI IRMAA fallback, gain/loss, fill conversion, NIIT | 33 | `revision5/irmaa_fallback_acceptance.log`: `SUMMARY 33 checks 0 failed` |
| Top-up, Money Market, survivor, RMD, threading | 87 | `revision5/topup_rmd_regression.log`: `FINAL 87 passed 0 failed` |
| RMDs before withdrawals begin | 20 | `revision5/predraw_rmd_regression.log`: `PRE-DRAW RMD FINAL 20 passed 0 failed` |
| Swing control mapping and scenario save/load | 10 | `revision5/gui_op.log`: `ALL 10 GUI OPERATIONAL CHECKS PASSED` |
| SS Optimizer vs direct Pro simulation | 51 | `Audit3_Optimizer_Integration_CleanReproduction.log`: `AUDIT3 OPTIMIZER REVISED INTEGRATION: 51 passed, 0 failed` |
| **Total** | **316** | **Zero reported failures** |

Additional independent GUI smoke execution: `revision5/gui_run.log` contains `PASS actual Swing Run Simulation completed` with 10 populated rows.

Full-size financial comparison: 20-year horizon; 1,000 solve paths, 600 fan paths, 23 binary-search iterations; fixed seeds, additional alternate seed and one/four-thread parity. The pre-draw RMD suite and optimizer integration used reduced path counts where appropriate; their results are separately identified and not misrepresented as full-fidelity.

## Changed-source coverage decisions

1. **Partial-year brokerage-sale tax:** Closed. The table's `saleTaxRow` uses `TaxEngine.compute` with and without the sale to isolate incremental sale-related tax, including indirect effects. The model keeps `tax = (tax - saleTaxRow) * startPror + saleTaxRow`. The fan path gap calculation applies the corresponding `saleTaxP`. Tested January/July/December, sale/no-sale, gain/loss, tax disabled, conversion disabled, extra seed and multithread.
2. **Missing prior MAGI fallback:** Closed. `saleFreeStandIn` excludes the current sale from the *estimate* of MAGI two years prior, while the gain remains in actual current MAGI and therefore affects future IRMAA. Explicit prior MAGI continues to override the estimate. The estimate is not a substitute for real historical MAGI if available.
3. **Roth conversion and sale interaction:** Closed. Tested flat and fill-to-target conversion, gross-to-net reconciliation, tax impacts, MAGI ceiling, incremental NIIT, and account balance accounting.
4. **Money Market, final-year top-ups, and portfolio depletion:** Closed. Independent RMD/reserve arithmetic, reserve exhaustion, early coverage ON/OFF, final-five-year top-ups, and portfolio-only Actual PoS preserved. The user's declared design deliberately does not count conditional external reserves toward optimizer portfolio PoS.
5. **Survivor and RMD sequencing:** Closed for changed interactions. RMD overage / reserve accumulation, survivor-year timing, death-year filing change, conversions, and 1/4-thread equivalence tested.
6. **SS Optimizer:** Closed. 51 additional checks compare direct Pro and optimizer Actual PoS, yearly real-dollar surplus, balances, terminal ranking metric, and sale/conversion/survivor cases. These were reproduced from an independent package extraction.
7. **Operational:** Closed for changed GUI inputs and persistence: new defaults, UI mapping, save/load, older scenarios, actual Swing Run Simulation; original sources compile with Java 21. GUI test used an Xvfb virtual display, not manual inspection on every supported desktop.

## Retained limitations (not acceptance defects)

- Money Market is an external, contingent, last-resort reserve. No future discretionary user contributions are guaranteed or counted toward portfolio-only Actual PoS.
- SS bridge tax gross-up is an intentionally accepted performance-conscious approximation.
- Roth-conversion incremental tax retains the previously accepted standard-deduction-consumption assumption.
- No estimated tax display before portfolio withdrawals begin; pre-withdrawal MAGI is retained for two-year IRMAA history.
- Guyton–Klinger is illustrative; Pro PoS remains authoritative.
- Brokerage integration represents a one-year sale assumed long-term. The code explicitly excludes short-term gains, dividends, loss carryforwards, and broader brokerage-account modeling (`RiskBased_OptSocSec_v2 (5).java`, lines ~3847–3852).
- The fallback used when actual prior-year MAGI is not entered is an estimate, not reconstructed historical income.
- A full-size pre-withdrawal RMD attempt previously exceeded execution time; the reduced-fidelity boundary test completed and passed. Broad load/performance testing and every UI workflow are not exhaustive.

## Final judgment

**Audit3 is closed: ACCEPTED WITH DOCUMENTED LIMITATIONS.** No additional regression is required merely to close this change set. Fresh testing is appropriate after new source changes, altered financial methodology, new supported tax rules, or a newly observed discrepancy.
