# Audit4 — Final coverage and acceptance review

**Review date:** November 14, 2026, America/Phoenix  
**Decision:** **ACCEPTED WITH DOCUMENTED LIMITATIONS**  
**Defects identified in tested November 14 change set:** None  
**Blocking coverage gaps:** None identified in the changed pathways  
**Scope:** Change-set audit and regression acceptance, not mathematical proof or independent verification of tax law, SSA law, market assumptions, or every possible stochastic trajectory.

## Exact versions examined

- **New code:** `RiskBased_OptSocSec_v2.java` — source header, lines 1–4, *“Last modified: Saturday, November 14, 2026 at 03:54 PM MST (UTC-7)”*. SHA-256: `24e80fe47109ff2903efe4bbf117dc834ed39359e939aab8c1a70a597568e186`.
- **Prior accepted baseline:** `RiskBased_OptSocSec_v2 (5).java` — November 2, 2026 revision; the prior Audit3 baseline. This version was compared with the new one for backward compatibility.
- **Supplied scenario:** `2026-11-05_near_2M_mult_17_13_great_candidate.ilscen`. SHA-256: `1241c09eee499bdbc7fe250b341f3d7b7878f472a67869e3c3d26d6f8965515f`. Exact file contains `mc.solvePaths=1200`, `mc.fanPaths=600`, `mc.binIters=25`, `spending.goGo=1.7`, `spending.slowGo=1.3`, `market.nomReturn=5.5`, and `market.stdDev=10.79`.
- The code and scenario inside the optimizer and reserve regression packages have **identical SHA-256 hashes** to the uploaded files. Thus the named logs apply to these exact uploaded bytes.
- **Additional check during this review:** `javac -encoding UTF-8 -d compile_nov14 RiskBased_OptSocSec_v2.java` returned code `0`, generating 56 `.class` files (Java 21).

## Executed regression evidence, non-overlapping test groups

| Audit4 stage | Log file and exact test-result quote | Checks | Failures |
|---|---|---:|---:|
| New-feature full-engine boundaries | `Audit4_Interim_Evidence.zip/logs/new_extra.log`: `AUDIT4_TOTAL\tPASSED=72\tFAILED=0` | 72 | 0 |
| Supplied scenario full-fidelity | `Audit4_Interim_Evidence.zip/logs/new_scenario_full.log`: `AUDIT4_TOTAL\tPASSED=12\tFAILED=0` | 12 | 0 |
| Roth-conversion tax-effect panel | `Audit4_Interim_Evidence.zip/logs/conversion_effect_direct.log`: `AUDIT4_CONV_COMPARE\tPASS=28\tFAIL=0` | 28 | 0 |
| Swing Run Simulation and comparison UI | `Audit4_Interim_Evidence.zip/logs/gui_smoke.log`: `AUDIT4_UI\tPASS=9\tFAIL=0` | 9 | 0 |
| Optimizer versus direct Pro | `Audit4_Optimizer_Integration_Evidence.zip/package/evidence/optimizer_scoring.log`: `AUDIT4_OPTIMIZER_TOTAL\tPASSED=121\tFAILED=0` | 121 | 0 |
| Optimizer GUI batch/fingerprint/cache | `Audit4_Optimizer_Integration_Evidence.zip/package/evidence/optimizer_operational.log`: `AUDIT4_OPT_OPS_TOTAL\tPASSED=27\tFAILED=0` | 27 | 0 |
| Dual-reserve boundaries and independent ledger | `Audit4_Reserve_Persistence_Evidence.zip/evidence/reserve_boundary.log`: `AUDIT4_BOUNDARY_TOTAL\tPASSED=113\tFAILED=0` | 113 | 0 |
| Real Swing scenario roundtrip | `Audit4_Reserve_Persistence_Evidence.zip/evidence/persistence.log`: `AUDIT4_PERSISTENCE_TOTAL\tPASSED=29\tFAILED=0` | 29 | 0 |
| Active-reserve full-fidelity scenario and 1-/4-thread parity | `Audit4_Reserve_Persistence_Evidence.zip/evidence/scenario_active_full.log`: `AUDIT4_SCENARIO_LIVE_TOTAL\tPASSED=23\tFAILED=0` | 23 | 0 |
| **Total** | **Nine individually totaled executed groups** | **434** | **0** |

Older baseline-specific checks and clean-room repeats are *not* counted again in the 434. A passing assertion count does not imply 434 independent financial models or exhaustive coverage. Compilation and source-diff review are additional evidence, not inflated into that assertion total.

## Source change-set coverage disposition

### Q26 — Split brokerage and regular Money Market, conversion tax funding, UI, scenario save/load — **PASS**

- **Two-pool reserve accounting**. New source lines 11810–11813: `double mmReserveRun = Math.max(0, inp.mmPrior);` and `double mmbRun = Math.max(0, inp.mmbPrior);`. The sum is displayed in `Money Mkt (total)`, while the brokerage part remains separately trackable in the tooltip.
- **Conversion-tax funding**. Source lines 12220–12224: `double fromB = Math.min(ctax[0], mmbRun);`, `mmbRun -= fromB;` and `convNetToRoth = (int) (conv - ctax[0] + fromB);`. Fan paths apply the corresponding `mmbPath` debit and `roth` credit at lines 11643–11651. Tested full, partial, zero-fund, survivor/RMD, and multithread cases.
- **Funding priority**. Source lines 12301–12307: `double earlyB = Math.max(0, mmEarly - Math.max(0, mmReserveRun));`, then regular and brokerage balances are decreased separately. Terminal funding performs an analogous split at lines 11970–11980. Independent two-reserve ledger checks, reserve exhaustion, and no-negative-balance boundaries pass.
- **Persistence**. Source lines 10301–10303 save `mmb.prior`, `mmb.paysConvTax`, and `accounts.hide401K`. Lines 10520–10524 specify old-file defaults `0`, `false`, `false`. The GUI roundtrip verified these values and that hidden 401(k)s remain included in the portfolio.
- The preexisting brokerage sale tax/NIIT rules, MAGI, IRMAA and recognized-loss behavior remained covered by the new engine and the previously accepted Audit3 regression suite; the new source diff does not replace the underlying tax algorithm.

### Q27 — Already-claimed Social Security date constraints and optimizer — **PASS**

- Source lines 7244–7250: `return claimY * 12 + claimM < todayY * 12 + todayM;` prevents past claim dates from being rescheduled.
- Source lines 7387–7408 lock the already-claimed date while still scanning a spouse's remaining choices. Source lines 7260–7278 disable the Run button when no dates remain.
- Source lines 7857–7866 append held dates to the optimizer fingerprint, protecting saved result reuse.
- Direct optimizer/Pro comparisons, actual eight-alternative batch, button enable/disable, fingerprint invalidation, and cache resume passed.

### Q28 — Market assumptions instructional material — **PASS (presentation review)**

- Source lines 1515–1559 modify tooltips and labels describing forecast returns and historical volatility, while the numeric defaults remain `spNomReturn = spinD(5.5,...)` and `spStdDev = spinD(10.79,...)`.
- The accepted scenario and new full-fidelity scenario results confirm no unintended change in those numeric inputs. **This is not an independent validation of the truth of forecast/historical claims included in the help text.**

### Q29 — Roth conversion tax effect, comparative run, result figures/layout — **PASS**

- Source lines 17736–17760: the companion run clones the simulation input, sets `off.convEnabled = false`, and calls `simulatePro` with the **same seed and fidelity**. Run Simulation remains disabled until comparison completes.
- Source lines 17785–17819 compare lifetime `Tax (est) + Conv Tax` from each run, provide both totals and ending Traditional balance, and support nominal/real display modes.
- Tested conversion on/off, MMB-funded taxes, real/nominal sums, asynchronous actual Swing completion, and nonconversion mode. New two-box layout and 401(k) hide/restore were exercised in GUI checks.
- **Interpretation limitation:** the displayed “Saves/Costs” is a *sum of modeled taxes on the median tables*, not a comprehensive after-tax economic net-present-value calculation or a guarantee of a better terminal portfolio. This is a communication limitation, not a computational inconsistency with the implemented metric.

## Two scenario controls

1. **Old scenario, new options inactive:** new vs. previous accepted source matched at full saved fidelity: first-year withdrawal `$148,701`, portfolio-only Actual PoS `79.3333%`, 31 annual rows and matching fan-path hash. Source: `Audit4_Interim_Review.md`, “Backward-compatibility control”, and `logs/old_scenario_full.log` vs. `logs/new_scenario_full.log`.
2. **Same source, new options intentionally active:** the full-fidelity 31-year test with brokerage cash/early coverage/conversion-tax funding yielded portfolio-only Actual PoS **84.8333%**, 509/600 paths, and 13 annual rows showing brokerage funding of conversion tax. One-thread and four-thread paths and rows matched. Source: `Audit4_Reserve_Persistence_Review.md`, “User's saved scenario with new reserve features on”, and `evidence/scenario_active_full.log`. **The two PoS percentages are not directly comparable as a change-set effect**, because the second test intentionally added external cash and changed funding options.

## Previously accepted methodological limitations remain unchanged

- Portfolio-only Actual PoS is intentionally distinct from supplemental funding success using external reserves.
- External Money Market cash is not presumed to be a permanently guaranteed resource for PoS solver feasibility.
- SS bridge tax gross-up remains an accepted approximation.
- Conversion-tax calculation assumes deduction usage as previously accepted.
- Pre-withdrawal taxes are not displayed; MAGI still feeds the two-year IRMAA lookback.
- Guyton–Klinger tab is illustrative; Pro PoS is authoritative.
- Brokerage model is intentionally simplified: no full taxable brokerage integration, short-term gain modeling, dividends or capital-loss carryforward.
- The comparison panel reports a modeled lifetime-tax sum, not present-value optimization.

## Final decision

**AUDIT4 CLOSED — ACCEPTED WITH DOCUMENTED LIMITATIONS.**

The code diff was reviewed by change category and reconciled with the actual executed tests. No identified defect or material uncovered interaction remains in the November 14 source change set to justify reopening the audit. The installed evidence verifies baseline reproducibility, active-feature financial accounting, RMD/survivor and optimizer integration, GUI behavior, persistence, and multithread determinism.

This is a change-set acceptance decision, not certification that every modeled tax rule or retirement outcome is correct in all possible scenarios. Reopen targeted regression tests for a future source change, a newly observed mismatch, or a substantive change to an accepted model assumption.
