# Audit5 post-fix verification package — November 19, 2026

The previous November 18 9:34 AM source and the new November 18 5:47 PM source are preserved unmodified under `source/`. `patch.diff` is their exact text diff. The `tests/` directory contains actual Java full-engine, tax, Swing, and optimizer harnesses. `scenario/` holds the earlier supplied November 16 plan and the audited derivative with the 2027 tax set selected. `postfix_logs/` retains raw output, including an anomalous standalone full-fidelity test and the controlled stabilized-loader repetitions.

To reproduce the targeted new-build gates: `bash run_postfix_quick.sh` on Linux with JDK 21+, Xvfb and `xvfb-run`. It compiles a clean copy of the attached Java source and runs the 104-case gain-band, 21-case GUI warning, 58-case full-engine sale, and 28-case tax/RMD suites (211 new assertions; 104+21+58+28 = 211). Those tests do not contact the network. The previously executed additional GUI, dialog, optimizer and thread-parity logs are also included.

Do not interpret the historical `full_runner.log` cross-process fingerprint difference as a post-fix capital-gain defect: it arose in a legacy test procedure and is not reproduced by the stabilized GUI-loader method. Its precise mechanism remains unverified; preserve the log for future evaluation.

Numerical 2027 LTCG thresholds are drawn from the uploaded Java source. This is a source-only audit, and official-law verification of those values was not performed.
