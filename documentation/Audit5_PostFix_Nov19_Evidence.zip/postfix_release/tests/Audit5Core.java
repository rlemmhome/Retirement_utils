import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;

public class Audit5Core {
 static int pass=0,fail=0;
 static void ck(String n,boolean c){System.out.println((c?"PASS":"FAIL")+"\t"+n); if(c)pass++;else fail++;}
 static int n(Object o,String k)throws Exception{return Audit4Engine.integer(o,k);}
 static double d(Object o,String k)throws Exception{return Audit4Engine.dbl(o,k);}
 static void set(Object o,String k,Object v)throws Exception{Audit4Engine.set(o,k,v);}
 static Object get(Object o,String k)throws Exception{return Audit4Engine.val(o,k);}
 static Object load(Audit4Engine.E e,String file) throws Exception {
  final Object[] out={null};final Throwable[] err={null};
  SwingUtilities.invokeAndWait(()->{try{
   Object f=e.cls.getConstructor().newInstance();
   Audit4Engine.meth(e.cls,"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class).invoke(f,new File(file),null,null);
   out[0]=f;
  }catch(Throwable t){err[0]=t;}});
  if(err[0]!=null)throw new RuntimeException(err[0]);
  Object in=Audit4Engine.meth(e.cls,"readInputs").invoke(out[0]);
  String st=((JProgressBar)get(out[0],"progressBar")).getString();
  ck("scenario loads without warning",st!=null&&!st.contains("Warnings"));
  ck("scenario 1.9m portfolio",n(in,"portfolio")==1900000);
  ck("scenario horizon 31",n(in,"horizon")==31);
  ck("scenario multiplier 1.6/1.3",Math.abs(d(in,"goGoMultiplier")-1.6)<1e-10&&Math.abs(d(in,"slowGoMultiplier")-1.3)<1e-10);
  ck("scenario older cash early disabled",!(Boolean)get(in,"mmCoversEarly"));
  ck("scenario old tax set default preserved", !Audit4Engine.has(in,"taxYear") || n(in,"taxYear")==2026);
  ((JFrame)out[0]).dispose();return in;
 }
 static void verify(Audit4Engine.E e,String name,Object i,Object r,int fan) throws Exception {
  List<?> rows=e.rows(r);int H=n(i,"horizon"); ck(name+" year rows",rows.size()==H);
  double[][] bal=(double[][])get(r,"fanBalances"),shorts=(double[][])get(r,"fanShort");
  ck(name+" fan path counts",bal.length==fan&&shorts.length==fan);
  boolean dom=true,cash=true,acct=true;int alive=0;
  for(int p=0;p<bal.length;p++){if(bal[p][H]>0)alive++;for(double x:bal[p])if(!Double.isFinite(x)||x<0)dom=false;for(double x:shorts[p])if(!Double.isFinite(x)||x<0)dom=false;}
  for(Object row:rows){if(Math.abs(n(row,"totalIncome")-n(row,"totalSpend")-n(row,"surplus"))>2)cash=false;
    if(n(row,"balance")<0||n(row,"mmBal")<0||n(row,"convTax")<0)acct=false;
    if(Audit4Engine.has(row,"mmbBal")&&(n(row,"mmbBal")<0||n(row,"mmbBal")>n(row,"mmBal")+2))acct=false;}
  ck(name+" financial domains",dom&&acct);ck(name+" income/spend reconciliation",cash);
  ck(name+" independent portfolio survival",Math.abs(d(r,"actualPoS")-alive/(double)fan)<1e-12);
  Object first=rows.get(0);String hash=Audit4Engine.fingerprint(r);
  System.out.printf(Locale.US,"SUMMARY\t%s\tpos=%.6f\twd=%d\ttax=%d\tmagi=%d\tconv=%d\tctax=%d\tMM=%d\tHASH=%s%n",name,d(r,"actualPoS"),n(first,"wdActual"),n(first,"tax"),n(first,"magi"),n(first,"conversion"),n(first,"convTax"),n(first,"mmBal"),hash);
  System.out.print("ROWCSV\t"+name);for(Object ro:rows){System.out.printf(Locale.US,"\t%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",n(ro,"calYear"),n(ro,"balance"),n(ro,"wdActual"),n(ro,"tax"),n(ro,"magi"),n(ro,"conversion"),n(ro,"convTax"),n(ro,"mmBal"),n(ro,"surplus"),n(ro,"irmaaTier"));}System.out.println();
 }
 public static void main(String[] a)throws Exception {
  String name=a[0],path=a[1];int solve=Integer.parseInt(a[2]),fan=Integer.parseInt(a[3]),it=Integer.parseInt(a[4]),threads=Integer.parseInt(a[5]);
  Audit4Engine.E e=new Audit4Engine.E();Object i=load(e,path);
  if(name.contains("noMM")){set(i,"mmPrior",0);set(i,"mmbPrior",0);set(i,"mmCoversEarly",false);set(i,"saleProceeds",0);set(i,"saleBasis",0);}
  if(name.contains("topoff"))set(i,"mmCoversEarly",true);
  if(name.contains("convOff"))set(i,"convEnabled",false);
  Object r=e.run(i,threads,solve,fan,it,0L);verify(e,name,i,r,fan);
  if(Audit4Engine.has(e.cls,"xxx"))System.out.println();
  if(name.contains("withSplits")){
   Class<?> cls=e.cls;Method still=Audit4Engine.meth(cls,"stillShortCount",double[][].class,double[][].class);Method split=Audit4Engine.meth(cls,"shortSplitCount",double[][].class,double[][].class,int.class);Method sh=Audit4Engine.meth(cls,"shortPathCount",double[][].class,double[][].class,int.class);
   double[][] fb=(double[][])get(r,"fanBalances"),fs=(double[][])get(r,"fanShort");int sc=(Integer)still.invoke(null,fb,fs),cnt=(Integer)sh.invoke(null,fs,fb,3);int[] sp=(int[])split.invoke(null,fs,fb,3);
   int own=0,er=0,lr=0,all=0;for(int p=0;p<fb.length;p++){
     int y0=-1;for(int y=1;y<fb[p].length;y++)if(fb[p][y]<=0){y0=y-1;break;}boolean left=false; if(y0>=0)for(int y=y0;y<fs[p].length;y++)if(fs[p][y]>0.5)left=true;if(y0>=0&&left)own++;
     boolean early=false,late=false;for(int y=0;y<fs[p].length;y++)if(fs[p][y]>.5){boolean islast=fs[p].length-y<=5;boolean graced=y>=fs[p].length-3&&!islast&&fb[p][y]>=fs[p][y];if(!graced){if(islast)late=true;else early=true;}}
     if(early)er++;if(late)lr++;if(early||late)all++;
   }
   ck("independent remaining short after depletion",sc==own);ck("independent short counts early/late/overall",sp[0]==er&&sp[1]==lr&&cnt==all);ck("combined success >= portfolio success",fan-own>=Math.round(d(r,"actualPoS")*fan));
   System.out.printf(Locale.US,"SPLIT\t%s\tportfolio=%.2f\tcombined=%.2f\tearly=%.2f\tlate=%.2f\tshort=%.2f\tdepletionShort=%d\tshortAny=%d%n",name,100*d(r,"actualPoS"),100.*(fan-own)/fan,100.*(fan-er)/fan,100.*(fan-lr)/fan,100.*(fan-all)/fan,own,all);
  }
  System.out.printf("AUDIT5_CORE_TOTAL PASSED=%d FAILED=%d%n",pass,fail);System.exit(fail==0?0:1);
 }
}
