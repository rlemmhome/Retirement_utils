import java.util.*;
public class Audit5Parity{
 static int pass=0,fail=0;
 static void ck(String s,boolean ok){System.out.println((ok?"PASS":"FAIL")+"\t"+s);if(ok)pass++;else fail++;}
 static void cmp(Audit4Engine.E e,String n,Object a,Object b)throws Exception{
  double[][] aa=(double[][])Audit4Engine.val(a,"fanBalances"),bb=(double[][])Audit4Engine.val(b,"fanBalances");
  int bad=0;double md=0;int which=-1;
  for(int p=0;p<aa.length;p++)for(int y=0;y<aa[p].length;y++)if(Double.doubleToLongBits(aa[p][y])!=Double.doubleToLongBits(bb[p][y])){bad++;if(which<0)which=p;md=Math.max(md,Math.abs(aa[p][y]-bb[p][y]));}
  boolean equal=bad==0;
  String ha=Audit4Engine.fingerprint(a),hb=Audit4Engine.fingerprint(b);
  ck(n+" fan balance exact identical",equal);ck(n+" combined fan paths hash equal",ha.equals(hb));
  System.out.printf(Locale.US,"PAIR\t%s\tPOS=%.6f/%.6f\tHASH=%s/%s\tdiffCells=%d firstPath=%d maxDiff=%.6f%n",n,Audit4Engine.dbl(a,"actualPoS"),Audit4Engine.dbl(b,"actualPoS"),ha,hb,bad,which,md);
  int rows=0;for(int y=0;y<e.rows(a).size();y++){for(String f:new String[]{"balance","wdActual","conversion","tax","convTax","magi","mmBal","surplus"})if(Audit4Engine.integer(e.rows(a).get(y),f)!=Audit4Engine.integer(e.rows(b).get(y),f)){rows++;break;}}
  ck(n+" median financial rows exact equal",rows==0);System.out.println("ROWS_DIFFER="+rows);
 }
 public static void main(String[] args)throws Exception{
  Audit4Engine.E e=new Audit4Engine.E();Object in=Audit5Core.load(e,args[0]);if(args[1].contains("early"))Audit4Engine.set(in,"mmCoversEarly",true);
  int s=Integer.parseInt(args[2]),f=Integer.parseInt(args[3]),b=Integer.parseInt(args[4]);long seed=0L;
  Object one=e.run(in,1,s,f,b,seed),four=e.run(in,4,s,f,b,seed);
  boolean quick=args.length>5;
  Object fourAgain=quick?null:e.run(in,4,s,f,b,seed),oneAgain=quick?null:e.run(in,1,s,f,b,seed);
  cmp(e,"1 vs 4",one,four);if(!quick){cmp(e,"4 repeat",four,fourAgain);cmp(e,"1 repeat",one,oneAgain);}
  System.out.printf("AUDIT5_PARITY_TOTAL PASSED=%d FAILED=%d%n",pass,fail);System.exit(fail==0?0:1);
 }
}
