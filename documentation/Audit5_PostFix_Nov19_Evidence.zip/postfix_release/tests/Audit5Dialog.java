import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.concurrent.atomic.*;

public class Audit5Dialog {
 static int p=0,f=0;
 static void ck(String s,boolean ok){System.out.println((ok?"PASS":"FAIL")+"\t"+s);if(ok)p++;else f++;}
 static JButton find(Container c,String name){for(Component x:c.getComponents()){if(x instanceof JButton b&&name.equals(b.getText()))return b;if(x instanceof Container k){JButton ret=find(k,name);if(ret!=null)return ret;}}return null;}
 static JLabel label(Container c,String starts){for(Component x:c.getComponents()){if(x instanceof JLabel l && l.getText()!=null&&l.getText().contains(starts))return l;if(x instanceof Container k){JLabel ret=label(k,starts);if(ret!=null)return ret;}}return null;}
 static void dialog(Object app,String reset,String ending)throws Exception{
  Class<?> cls=app.getClass();AtomicReference<Throwable> err=new AtomicReference<>();AtomicBoolean didReset=new AtomicBoolean(),done=new AtomicBoolean(),validValues=new AtomicBoolean(),notes=new AtomicBoolean();
  SwingUtilities.invokeAndWait(()->{
   long started=System.currentTimeMillis();
   javax.swing.Timer tick=new javax.swing.Timer(100,null);
   tick.addActionListener(ev->{
    if(System.currentTimeMillis()-started>12000){tick.stop();err.set(new RuntimeException("dialog automation timeout"));for(Window w:Window.getWindows())if(w instanceof Dialog&&w.isShowing())w.dispose();return;}
    for(Window w:Window.getWindows())if(w instanceof JDialog dlg&&dlg.isShowing()&&dlg.getTitle().contains("Edit base thresholds")){
      JButton rst=find(dlg,reset),end=find(dlg,ending);
      if(rst==null||end==null)continue;
      if(!didReset.get()){rst.doClick();didReset.set(true);return;}
      JLabel note=label(dlg,"Tax year ");
      notes.set(note!=null&&note.getText().contains(reset.endsWith("2027")?"Tax year 2027":"Tax year 2026"));
      validValues.set(note!=null&&note.getToolTipText().contains(reset.endsWith("2027")?"1,189.20":"1,148.40"));
      end.doClick();done.set(true);tick.stop();return;
    }
   });tick.start();
   try{Audit4Engine.meth(cls,"showThresholdDialog").invoke(app);}catch(Throwable t){err.set(t);}finally{tick.stop();}
  });
  ck(reset+" dialog reset button exercised",didReset.get()&&done.get()&&err.get()==null);
  ck(reset+" dialog note reflects tax year",notes.get());
  ck(reset+" dialog surcharge tooltip reflects year",validValues.get());
 }
 public static void main(String[] args)throws Exception{
  Class<?> cls=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2");AtomicReference<Object>a=new AtomicReference<>();AtomicReference<Throwable>err=new AtomicReference<>();
  SwingUtilities.invokeAndWait(()->{try{a.set(cls.getConstructor().newInstance());Audit4Engine.meth(cls,"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class).invoke(a.get(),new File(args[0]),null,null);}catch(Throwable t){err.set(t);}});if(err.get()!=null)throw new RuntimeException(err.get());Object app=a.get();
  ck("legacy input starts in 2026 tax set",Audit4Engine.integer(app,"editTaxYear")==2026);
  dialog(app,"Reset to 2027","Cancel");
  ck("Cancel discards tax year and values",Audit4Engine.integer(app,"editTaxYear")==2026 && Math.abs((Double)Audit4Engine.val(app,"editStdDedMFJ")-32200)<1e-5);
  dialog(app,"Reset to 2027","OK");
  ck("OK commits 2027 tax year",Audit4Engine.integer(app,"editTaxYear")==2027);
  ck("OK commits 2027 MFJ deduction",Math.abs((Double)Audit4Engine.val(app,"editStdDedMFJ")-33200)<1e-5);
  ck("OK commits 2027 IRMAA first cliff",Math.abs(((double[])Audit4Engine.val(app,"editIrmaaThreshMFJ"))[0]-224000)<1e-5);
  dialog(app,"Reset to 2026","OK");
  ck("Reset2026 OK returns legacy set",Audit4Engine.integer(app,"editTaxYear")==2026&&Math.abs((Double)Audit4Engine.val(app,"editStdDedMFJ")-32200)<1e-5);
  SwingUtilities.invokeAndWait(()->((JFrame)app).dispose());
  System.out.printf("AUDIT5_DIALOG_TOTAL PASSED=%d FAILED=%d%n",p,f);System.exit(f==0?0:1);
 }
}
