import java.lang.reflect.*;
import java.util.*;

/** Independent LTCG statutory-band/stacking regression against actual TaxEngine. */
public class Audit5PostFixTax {
 static int pass, fail;
 static void ck(String msg,boolean yes){System.out.println((yes?"PASS":"FAIL")+"\t"+msg);if(yes)pass++;else fail++;}
 static boolean near(double a,double b){return Math.abs(a-b)<=1e-7*Math.max(1,Math.abs(b));}
 static Object call(Class<?> c,String n,Class<?>[] ty,Object... xs)throws Exception{return Audit4Engine.meth(c,n,ty).invoke(null,xs);}
 public static void main(String[] argv)throws Exception {
  Class<?> te=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2$TaxEngine");
  Class<?> fs=Class.forName(te.getName()+"$FilingStatus");
  Object MFJ=Enum.valueOf((Class)fs,"MFJ"), SINGLE=Enum.valueOf((Class)fs,"SINGLE");
  Method fed=Audit4Engine.meth(te,"fedTaxPref",double.class,double.class,double.class,fs,double[].class);
  Method b0=Audit4Engine.meth(te,"ltcg0TopFor",int.class,fs),b15=Audit4Engine.meth(te,"ltcg15TopFor",int.class,fs);
  Method set=Audit4Engine.meth(te,"setActiveBase",double.class,double.class,double.class,double.class,int.class);
  Method reset=Audit4Engine.meth(te,"resetThresholds");
  Method sig=Audit4Engine.meth(te,"thresholdSignature");
  reset.invoke(null);
  ck("2026 zero default LTCG fingerprint",!((String)sig.invoke(null)).contains(";ltcg="));
  int[] years={2026,2027,2028};Object[] fss={MFJ,SINGLE};String[] names={"MFJ","Single"};
  double[][] tops0={{98900,49450},{102100,51050},{102100,51050}};
  double[][] tops15={{613700,545500},{633600,563200},{633600,563200}};
  for(int yi=0;yi<years.length;yi++){
   int y=years[yi];set.invoke(null,y==2026?32200d:33200d,y==2026?16100d:16600d,y==2026?1650d:1700d,y==2026?2050d:2100d,y);
   String signature=(String)sig.invoke(null);
   ck(y+" fingerprint capital-gain version",(y==2026)==!signature.contains(";ltcg=2027"));
   for(int fi=0;fi<2;fi++){
    Object filing=fss[fi];String prefix=y+" "+names[fi];double zero=tops0[yi][fi],fifteen=tops15[yi][fi];
    ck(prefix+" 0% top chosen",near((double)b0.invoke(null,y,filing),zero));
    ck(prefix+" 15% top chosen",near((double)b15.invoke(null,y,filing),fifteen));
    // Gain-only case at 0%/15%/20% boundaries; compares independent per-band arithmetic.
    for(double gain:new double[]{zero-1,zero,zero+1,fifteen-1,fifteen,fifteen+1}){
     double[] bands=new double[3];double tax=(double)fed.invoke(null,gain,gain,1d,filing,bands);
     double exp0=Math.min(gain,zero),exp15=Math.min(Math.max(gain-zero,0),fifteen-zero),exp20=Math.max(0,gain-fifteen);
     ck(prefix+" boundary gain="+(long)gain+" band allocation",near(bands[0],exp0)&&near(bands[1],exp15)&&near(bands[2],exp20));
     // The raw preference tax should be correct for zero ordinary income, no need to compare tax law externally.
     ck(prefix+" boundary gain="+(long)gain+" federal preferential tax",near(tax,0.15*exp15+0.20*exp20));
    }
    // Stacking ordinary income below 0% top and across both preferential boundaries
    double ordinary=10000d, pref=zero-ordinary+1000d;
    double[] bands=new double[3];fed.invoke(null,ordinary+pref,pref,1d,filing,bands);
    ck(prefix+" capital gains stacked over ordinary taxable income",near(bands[0],zero-ordinary)&&near(bands[1],1000)&&near(bands[2],0));
    // An inflation factor is applied exactly once.
    double inf=1.10, g=zero*inf+500;double[] inflated=new double[3];fed.invoke(null,g,g,inf,filing,inflated);
    ck(prefix+" 10% indexed top",near(inflated[0],zero*inf)&&near(inflated[1],500)&&near(inflated[2],0));
   }
  }
  // Reproduce original Audit5 2027 defect's exact public diagnostic
  set.invoke(null,32200d,16100d,1650d,2050d,2026);
  double[] oldBands=new double[3];fed.invoke(null,100000d,10000d,1d,MFJ,oldBands);
  set.invoke(null,33200d,16600d,1700d,2100d,2027);
  double[] newBands=new double[3];fed.invoke(null,100000d,10000d,1d,MFJ,newBands);
  ck("Audit5 original 2026 gain band $8,900 zero $1,100 fifteen",near(oldBands[0],8900)&&near(oldBands[1],1100));
  ck("Audit5 FIX: 2027 gain band $10,000 zero $0 fifteen",near(newBands[0],10000)&&near(newBands[1],0));
  ck("Audit5 FIX: 2027 gain bands differ from prior version",!Arrays.equals(oldBands,newBands));
  reset.invoke(null);
  ck("reset returns 2026 capital-gain bands",near((double)b0.invoke(null,2026,MFJ),98900)&&!((String)sig.invoke(null)).contains(";ltcg=2027"));
  System.out.printf("AUDIT5_POSTFIX_LTCG_TOTAL PASSED=%d FAILED=%d%n",pass,fail);
  System.exit(fail==0?0:1);
 }
}
