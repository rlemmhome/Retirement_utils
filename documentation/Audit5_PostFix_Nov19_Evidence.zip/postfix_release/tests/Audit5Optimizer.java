import javax.swing.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
public class Audit5Optimizer {
 static int p=0,f=0;static void ck(String s,boolean b){System.out.println((b?"PASS":"FAIL")+"\t"+s);if(b)p++;else f++;}
 static <T>T get(Object x,String f)throws Exception{return (T)Audit4Engine.val(x,f);}
 static void edt(Runnable x)throws Exception{SwingUtilities.invokeAndWait(x);}
 public static void main(String[] args)throws Exception{
  Class<?> cls=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2");final Object[] aa={null};final Throwable[] er={null};
  edt(()->{try{aa[0]=cls.getConstructor().newInstance();Audit4Engine.meth(cls,"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class).invoke(aa[0],new File(args[0]),null,null);}catch(Throwable t){er[0]=t;}});if(er[0]!=null)throw new RuntimeException(er[0]);Object a=aa[0];
  JCheckBox cover=get(a,"chkMmCoversEarly"),opt=get(a,"chkOptimize");JSpinner sy=get(a,"spManSSStartYear"),sm=get(a,"spManSSStartMonth");
  JSpinner solve=get(a,"spMcSolvePaths"),fan=get(a,"spMcFanPaths"),bi=get(a,"spBinaryIters");JComboBox<?>grid=get(a,"cmbOptGrid");
  edt(()->{opt.setSelected(true);sy.setValue(2025);sm.setValue(11);solve.setValue(50);fan.setValue(20);bi.setValue(8);grid.setSelectedIndex(0);cover.setSelected(true);});
  ck("early saving checkbox set ON in Pro UI",cover.isSelected());
  Method cfgM=Audit4Engine.meth(cls,"readBatchCfg");Object cfg=cfgM.invoke(a),b=get(cfg,"base");
  ck("optimizer cfg forcibly turns early reserve off",!Audit4Engine.bool(b,"mmCoversEarly"));
  ck("optimizer held user claim November 2025",Audit4Engine.integer(b,"manSSStartYear")==2025&&Audit4Engine.integer(b,"manSSStartMonth")==11);
  Method fp=Audit4Engine.meth(cls,"batchFingerprint",cfg.getClass());String on=(String)fp.invoke(a,cfg);
  edt(()->cover.setSelected(false));Object offCfg=cfgM.invoke(a);ck("optimizer ignores early-savings toggle for fingerprint",on.equals((String)fp.invoke(a,offCfg)));
  edt(()->cover.setSelected(true));Audit4Engine.set(a,"headlessBatch",true);
  Method batch=Audit4Engine.meth(cls,"runSsOptimizerCore",cfg.getClass(),java.util.function.Consumer.class);List<String> messages=new ArrayList<>();
  try{batch.invoke(a,cfg,(java.util.function.Consumer<String>)(s->messages.add(s)));}catch(InvocationTargetException t){throw new RuntimeException(t.getCause());}
  int ran=Audit4Engine.integer(a,"optRunRan");
  ck("real optimizer batch executed combinations",ran>=3&&ran<=20);
  ck("optimizer finished full batch",messages.stream().anyMatch(s->s.contains("100%")));
  ck("optimizer batch no saved-result error",get(a,"batchWriteError")==null);
  File file=(File)Audit4Engine.meth(cls,"batchFile").invoke(a);
  ck("optimizer CSV saved",file.isFile()&&file.length()>40);
  ck("optimizer CSV retains claim date",java.nio.file.Files.readString(file.toPath()).contains("2025"));
  messages.clear();batch.invoke(a,cfg,(java.util.function.Consumer<String>)(s->messages.add(s)));
  ck("optimizer resumes without rerun for unchanged plan",Audit4Engine.integer(a,"optRunRan")==0);
  ck("optimizer resume explicitly displayed",messages.stream().anyMatch(s->s.contains("Resuming")));
  // Active 2027 tax year must keep a different signature from the old 2026 set.
  String fp2027=on;
  edt(()->{try{Audit4Engine.meth(cls,"applyTaxYearSet",int.class).invoke(a,2026);Audit4Engine.meth(cls,"syncActiveThresholds").invoke(a);}catch(Throwable t){er[0]=t;}});
  if(er[0]!=null)throw new RuntimeException(er[0]);
  ck("reset tax set invalidates optimizer batch cache",!fp2027.equals((String)fp.invoke(a,cfgM.invoke(a))));
  edt(()->((JFrame)a).dispose());
  System.out.printf("AUDIT5_OPTIMIZER_TOTAL PASSED=%d FAILED=%d%n",p,f);System.exit(f==0?0:1);
 }
}
