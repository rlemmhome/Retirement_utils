import java.awt.*;
import java.io.*;
import java.lang.reflect.*;
import javax.swing.*;
import java.util.*;
import java.util.concurrent.atomic.*;
public class Audit5PostFixGui {
 static int passed,failed;
 static void ck(String x,boolean b){System.out.println((b?"PASS":"FAIL")+"\t"+x);if(b)passed++;else failed++;}
 static <T> T fld(Object a,String n)throws Exception{return (T)Audit4Engine.val(a,n);}
 static void edt(Runnable r)throws Exception{SwingUtilities.invokeAndWait(r);}
 static void doM(Object a,String n,Class<?>[] types,Object...v)throws Exception{Audit4Engine.meth(a.getClass(),n,types).invoke(a,v);}
 static void load(Object app,String file)throws Exception{AtomicReference<Throwable> e=new AtomicReference<>();edt(()->{try{doM(app,"loadScenarioFromFile",new Class<?>[]{File.class,JTextField.class,JComboBox.class},new File(file),null,null);}catch(Throwable t){e.set(t);}});if(e.get()!=null)throw new RuntimeException(e.get());}
 static void setYear(Object app,int y)throws Exception{AtomicReference<Throwable> e=new AtomicReference<>();edt(()->{try{doM(app,"applyTaxYearSet",new Class<?>[]{int.class},y);doM(app,"syncActiveThresholds",new Class<?>[]{});}catch(Throwable t){e.set(t);}});if(e.get()!=null)throw new RuntimeException(e.get());}
 static boolean run(Object app)throws Exception{
  edt(()->{((JSpinner)unchecked(app,"spMcSolvePaths")).setValue(50);((JSpinner)unchecked(app,"spMcFanPaths")).setValue(20);((JSpinner)unchecked(app,"spBinaryIters")).setValue(8);((JCheckBox)unchecked(app,"chkRandomize")).setSelected(false);((JButton)unchecked(app,"btnRun")).doClick();});
  long end=System.nanoTime()+90_000_000_000L;
  while(System.nanoTime()<end){Thread.sleep(100);JProgressBar pb=fld(app,"progressBar");String t=pb.getString();JButton button=fld(app,"btnRun");if(t!=null&&t.startsWith("Complete --")&&button.isEnabled())return true;if(t!=null&&t.startsWith("Error:")){System.out.println("RUN_ERROR="+t);return false;}}return false;
 }
 static Object unchecked(Object a,String n){try{return Audit4Engine.val(a,n);}catch(Exception e){throw new RuntimeException(e);}}
 public static void main(String[]args)throws Exception{
  Class<?> cls=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2");AtomicReference<Object>a=new AtomicReference<>();edt(()->{try{a.set(cls.getConstructor().newInstance());}catch(Throwable t){throw new RuntimeException(t);}});
  Object app=a.get();
  load(app,args[0]);
  JLabel line=fld(app,"lblTaxYearLine"),note=fld(app,"lblDetail");
  ck("legacy file taxYear 2026 is retained",(int)Audit4Engine.integer(app,"editTaxYear")==2026);
  ck("legacy scenario visibly flags year mismatch",line.getText().contains("Tax figures: 2026")&&line.getText().contains("plan starts in 2027"));
  ck("legacy mismatch line uses warning red",line.getForeground().equals(new Color(176,0,0)));
  ck("warning tooltip explains compatibility",line.getToolTipText().contains("scenario saved before November 18"));
  ck("legacy year warning includes correction steps",line.getText().contains("Reset to 2027"));
  ck("legacy first simulation completes",run(app));
  Object res=fld(app,"lastResults");
  ck("legacy financial result snapshots the 2026 tax year",res!=null&&Audit4Engine.integer(res,"taxYear")==2026);
  ck("legacy results header flags tax figures 2026",note.isVisible()&&note.getText().contains("Tax figures 2026")&&note.getText().contains("plan starts 2027"));
  setYear(app,2027);
  ck("reset to matching year changes scenario line to grey",line.getForeground().equals(new Color(110,110,110))&&line.getText().contains("Tax figures: 2027"));
  ck("reset to 2027 uses correct tax year",Audit4Engine.integer(app,"editTaxYear")==2027);
  ck("matching year run completes",run(app));
  Object res2=fld(app,"lastResults");
  ck("matching result records 2027 tax base",res2!=null&&Audit4Engine.integer(res2,"taxYear")==2027);
  ck("matching result header removes old mismatch marker",!note.getText().contains("Tax figures 2026"));
  JSpinner sy=fld(app,"spSimStartYear");edt(()->sy.setValue(2028));
  ck("future year flags newest available 2027 tax base",line.getText().contains("plan starts in 2028")&&line.getText().contains("Tax figures: 2027"));
  ck("future year explains unavailable 2028 tables",line.getText().contains("No 2028 figures yet"));
  edt(()->sy.setValue(2027));
  ck("return to matching year removes warning",line.getForeground().equals(new Color(110,110,110)));
  Class<?> te=Class.forName(cls.getName()+"$TaxEngine");String sig=(String)Audit4Engine.meth(te,"thresholdSignature").invoke(null);
  ck("2027 fingerprint carries capital gain version tag",sig.contains(";ltcg=2027"));
  String tip=(String)Audit4Engine.meth(cls,"surchargeTipHtml",int.class).invoke(null,2027);
  ck("2027 tax year tooltip includes MFJ capital gain bands",tip.contains("102,100")&&tip.contains("633,600"));
  ck("2027 tax year tooltip includes Single capital gain bands",tip.contains("51,050")&&tip.contains("563,200"));
  ck("2027 tax year tooltip still includes IRMAA surcharge",tip.contains("IRMAA surcharge")&&tip.contains("1,189.20"));
  String t26=(String)Audit4Engine.meth(cls,"surchargeTipHtml",int.class).invoke(null,2026);
  ck("2026 tax year tooltip still describes 2026 bands",t26.contains("98,900")&&t26.contains("613,700"));
  edt(()->((JFrame)app).dispose());
  System.out.printf("AUDIT5_POSTFIX_GUI_TOTAL PASSED=%d FAILED=%d%n",passed,failed);System.exit(failed==0?0:1);
 }
}
