import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.*;

public class Audit5GuiPostFix {
 static int p=0,f=0;static void ck(String s,boolean ok){System.out.println((ok?"PASS":"FAIL")+"\t"+s);if(ok)p++;else f++;}
 static <T>T get(Object o,String field)throws Exception{return (T)Audit4Engine.val(o,field);}
 static void edt(Runnable r)throws Exception{SwingUtilities.invokeAndWait(r);}
 static Object app(Class<?> cls)throws Exception {final Object[] a={null};final Throwable[] t={null};edt(()->{try{a[0]=cls.getConstructor().newInstance();}catch(Throwable x){t[0]=x;}});if(t[0]!=null)throw new RuntimeException(t[0]);return a[0];}
 static void load(Object a,File file)throws Exception{final Throwable[] t={null};edt(()->{try{Audit4Engine.meth(a.getClass(),"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class).invoke(a,file,null,null);}catch(Throwable x){t[0]=x;}});if(t[0]!=null)throw new RuntimeException(t[0]);}
 static int spin(Object a,String f)throws Exception{return ((Number)((JSpinner)get(a,f)).getValue()).intValue();}
 static int s2(Object a,String field)throws Exception{return (Integer)Audit4Engine.val(a,field);}
 static int countCollapsed(Container root){int[] a={0};visit(root,a);return a[0];}
 static void visit(Container r,int[] c){for(Component x:r.getComponents()){if(x instanceof JPanel j && j.getLayout() instanceof BoxLayout && j.getComponentCount()>=2 && j.getComponent(0) instanceof JPanel && j.getComponent(j.getComponentCount()-1) instanceof JPanel){JPanel last=(JPanel)j.getComponent(j.getComponentCount()-1);if(!last.isVisible())c[0]++;}if(x instanceof Container k)visit(k,c);}}
 static Properties props(File file)throws Exception{Properties p=new Properties();try(FileInputStream in=new FileInputStream(file)){p.load(in);}return p;}
 static JFileChooser chooser(Component root){if(root instanceof JFileChooser j)return j;if(root instanceof Container c)for(Component x:c.getComponents()){JFileChooser y=chooser(x);if(y!=null)return y;}return null;}
 static void save(Object a,File dst)throws Exception{
   final boolean[] sel={false};final Throwable[] err={null};
   edt(()->{javax.swing.Timer tick=new javax.swing.Timer(100,null);tick.addActionListener(ev->{for(Window w:Window.getWindows())if(w.isShowing()&&w instanceof Dialog){JFileChooser ch=chooser(w);if(ch!=null&&ch.isShowing()){try{ch.setSelectedFile(dst);sel[0]=true;tick.stop();ch.approveSelection();}catch(Throwable t){err[0]=t;tick.stop();}break;}}});tick.start();try{Audit4Engine.meth(a.getClass(),"saveScenario",JTextField.class).invoke(a,new JTextField("audit5"));}catch(Throwable t){err[0]=t;}finally{tick.stop();}});
   ck("actual Save Scenario file dialog used",sel[0]&&err[0]==null);
 }
 static boolean waitFor(Object a, boolean convOn)throws Exception{
  JButton run=get(a,"btnRun");JProgressBar prog=get(a,"progressBar");JLabel title=get(a,"lblConvEffect");
  long end=System.nanoTime()+150_000_000_000L;
  while(System.nanoTime()<end){Thread.sleep(150);String st=prog.getString(),v=title.getText();if(st!=null&&st.startsWith("Error:")){System.out.println("ENGINE_ERROR "+st);return false;}
   if(run.isEnabled()&&st!=null&&st.startsWith("Complete --")&& (convOn ? (v.startsWith("Saves")||v.startsWith("Costs")) : v.equals("Roth conversions are off"))){return true;}}
  System.out.println("TIMEOUT "+prog.getString()+" metric="+title.getText());return false;
 }
 public static void main(String[] args)throws Exception{
  File scenario=new File(args[0]),special=new File(args[1]),roundtrip=new File(args[2]);Files.deleteIfExists(roundtrip.toPath());
  String userHome=System.getProperty("user.home");Path panel=Path.of(userHome,".retirement_utils/.incomelab/calibration/panelstate.prefs");Files.createDirectories(panel.getParent());Files.writeString(panel,"THIS_MUST_NOT_CHANGE=yes\n");String oldPanel=Files.readString(panel);
  Class<?> cls=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2");Object a=app(cls);
  ck("initial collapsible cards start closed",countCollapsed((Container)a)>=12);
  ck("legacy panelstate prefs not rewritten on startup",Files.readString(panel).equals(oldPanel));
  ck("build stamp is current revision",((JFrame)a).getTitle().contains("November 18, 2026 at 5:47 PM"));
  ck("2026 reset available during 2026", (Integer)Audit4Engine.meth(cls,"reset2026State",LocalDate.class).invoke(null,LocalDate.of(2026,11,18))==0);
  ck("2026 reset disabled Jan 2027",(Integer)Audit4Engine.meth(cls,"reset2026State",LocalDate.class).invoke(null,LocalDate.of(2027,1,15))==1);
  ck("2026 reset hidden Feb 2027", (Integer)Audit4Engine.meth(cls,"reset2026State",LocalDate.class).invoke(null,LocalDate.of(2027,2,1))==2);
  load(a,scenario);
  ck("legacy scenario chooses 2026 tax set",s2(a,"editTaxYear")==2026);
  ck("legacy scenario kept 2026 first MFJ cliff",Math.abs(((double[])get(a,"editIrmaaThreshMFJ"))[0]-218000)<0.001);
  ck("legacy scenario kept 2026 deduction",Math.abs((Double)get(a,"editStdDedMFJ")-32200)<0.001);
  ck("legacy scenario maps 22 pct bracket",((JComboBox<?>)get(a,"cmbFillBracket")).getSelectedIndex()==2);
  ck("legacy source contains both original bracket keys",props(scenario).containsKey("tax.fillBracketDropdown")&&props(scenario).containsKey("tax.fillBracketTop"));
  load(a,special);
  ck("new scenario activates 2027 tax set",s2(a,"editTaxYear")==2027);
  ck("2027 MFJ IRMAA first cliff",Math.abs(((double[])get(a,"editIrmaaThreshMFJ"))[0]-224000)<0.001);
  ck("2027 single first cliff",Math.abs(((double[])get(a,"editIrmaaThreshSingle"))[0]-112000)<0.001);
  ck("2027 MFJ 2027 standard deduction",Math.abs((Double)get(a,"editStdDedMFJ")-33200)<0.001);
  ck("2027 Single 2027 standard deduction",Math.abs((Double)get(a,"editStdDedSingle")-16600)<0.001);
  ck("2027 age65 add-ons",Math.abs((Double)get(a,"editAdd65MFJ")-1700)<0.001&&Math.abs((Double)get(a,"editAdd65Single")-2100)<0.001);
  ck("2027 10 percent ordinary top",Math.abs(((double[])get(a,"editBracketTopMFJ"))[0]-25600)<0.001);
  ck("IRMAA dropdown includes no-limit tier",((JComboBox<?>)get(a,"cmbFillIrmaaTier")).getItemCount()==6);
  ck("bracket dropdown includes all ordinary tiers",((JComboBox<?>)get(a,"cmbFillBracket")).getItemCount()==7);
  ck("Fill tooltip reflects 2027 cliff",((JSpinner)get(a,"spConvBuffer")).getToolTipText().contains("224,000"));
  ck("old card layout preference still never changed",Files.readString(panel).equals(oldPanel));
  Object inp=Audit4Engine.meth(cls,"readInputs").invoke(a);
  ck("loaded first-year target uses new threshold",Audit4Engine.integer(inp,"baseYear")==2027 && Math.abs(((double[])get(a,"editIrmaaThreshMFJ"))[0]-224000)<0.001);
  JCheckBox cover=get(a,"chkMmCoversEarly");edt(()->cover.setSelected(true));
  Object cfg=Audit4Engine.meth(cls,"readBatchCfg").invoke(a);Object optBase=get(cfg,"base");
  ck("optimizer forces early reserve use off",!(Boolean)get(optBase,"mmCoversEarly"));
  String fpOn=(String)Audit4Engine.meth(cls,"batchFingerprint",cfg.getClass()).invoke(a,cfg);
  edt(()->cover.setSelected(false));Object cfgOff=Audit4Engine.meth(cls,"readBatchCfg").invoke(a);String fpOff=(String)Audit4Engine.meth(cls,"batchFingerprint",cfgOff.getClass()).invoke(a,cfgOff);
  ck("optimizer fingerprint ignores early reserve checkbox",fpOn.equals(fpOff));
  edt(()->cover.setSelected(true));
  save(a,roundtrip);
  ck("2027 round-trip file written",roundtrip.exists()&&roundtrip.length()>1000);
  Properties saved=props(roundtrip);
  ck("saved thresholdYear 2027",saved.getProperty("tax.thresholdYear").equals("2027"));
  ck("saved new deduction fields",saved.getProperty("tax.editStdDed").contains("33200")&&saved.getProperty("tax.editAdd65").contains("1700"));
  ck("saved early coverage on",saved.getProperty("mm.coversEarly").equals("true"));
  ck("saved bracket new key present",saved.containsKey("tax.fillBracketTop"));
  Object b=app(cls);load(b,roundtrip);
  ck("fresh GUI reloads 2027 thresholds",s2(b,"editTaxYear")==2027&&Math.abs(((double[])get(b,"editIrmaaThreshMFJ"))[0]-224000)<.001);
  ck("fresh GUI reloads early coverage on",((JCheckBox)get(b,"chkMmCoversEarly")).isSelected());
  ck("fresh GUI reloads 2027 deduction",Math.abs((Double)get(b,"editStdDedMFJ")-33200)<.001);
  ck("no stale panelstate file update after saving",Files.readString(panel).equals(oldPanel));
  JSpinner solve=get(b,"spMcSolvePaths"),fan=get(b,"spMcFanPaths"),it=get(b,"spBinaryIters");JButton run=get(b,"btnRun");JCheckBox rnd=get(b,"chkRandomize"),con=get(b,"chkConvEnabled");
  edt(()->{solve.setValue(50);fan.setValue(20);it.setValue(8);rnd.setSelected(false);run.doClick();});
  ck("real Run Simulation button conversion-ON run completes",waitFor(b,true));
  Object res=get(b,"lastResults"),other=get(b,"convEffectOther");
  ck("real GUI has main and comparison results",res!=null&&other!=null);
  String ct=get(b,"convEffectSubText");
  ck("new conversion comparison shows survivor and Traditional",ct!=null&&ct.contains("Traditional at plan end")&&ct.contains("Survivor years tax"));
  JLabel effect=get(b,"lblConvEffect");ck("new detailed hover shows RMDs and forced tax",effect.getToolTipText().contains("RMDs over the plan")&&effect.getToolTipText().contains("extra tax they caused"));
  JLabel[] q=get(b,"qaVal");
  ck("top summary first withdrawal equals first annual row",q[0].getText().contains(String.format("%,d",Audit4Engine.integer(((java.util.List<?>)get(res,"medianRows")).get(0),"wdActual"))));
  ck("top summary contains portfolio and combined survival",q[2].getText().endsWith("%")&&q[3].getText().endsWith("%"));
  ck("top summary marks savings top-off on",((JLabel)get(b,"qaTopOff")).getText().equals(": ON"));
  ck("top summary early/late split percentages present",q[5].getText().contains("of paths")&&q[6].getText().contains("of paths"));
  edt(()->{con.setSelected(false);run.doClick();});
  ck("real Run Simulation button conversion-OFF companion completes",waitFor(b,false));
  Object offRes=get(b,"lastResults"),offCmp=get(b,"convEffectOther");
  ck("conversion-off comparison really simulated conversions",offCmp!=null&&Audit4Engine.integer(((java.util.List<?>)get(offCmp,"medianRows")).get(0),"conversion")>0);
  ck("conversion-off display reports RMDs",((String)get(b,"convEffectSubText")).contains("RMDs over the plan"));
  ck("conversions-off explanatory comparison present",((String)get(b,"convEffectSubText")).contains("If you converted"));
  edt(()->{((JFrame)a).dispose();((JFrame)b).dispose();});
  System.out.printf("AUDIT5_GUI_TOTAL PASSED=%d FAILED=%d%n",p,f);System.exit(f==0?0:1);
 }
}
