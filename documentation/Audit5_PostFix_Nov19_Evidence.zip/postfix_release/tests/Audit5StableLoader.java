import java.io.*;import java.lang.reflect.*;import java.util.*;import javax.swing.*;import java.util.concurrent.atomic.*;
/** Race-free GUI input capture; scenario loaded only after GUI deferred initialization has drained. */
public class Audit5StableLoader {
 static volatile Object frame; static volatile Object in;
 static void edt(Runnable r)throws Exception{SwingUtilities.invokeAndWait(r);}
 static Object get(Object a,String n){try{return Audit4Engine.val(a,n);}catch(Exception e){throw new RuntimeException(e);}}
 static String fingerprint(Object input)throws Exception{ArrayList<String> chunks=new ArrayList<>();for(Field f:input.getClass().getDeclaredFields()){if(Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);Object v=f.get(input);String t=v!=null&&v.getClass().isArray()?Arrays.deepToString(new Object[]{v}):String.valueOf(v);chunks.add(f.getName()+"="+t);}Collections.sort(chunks);return String.join("|",chunks);}
 public static void main(String[]a)throws Exception{
  Audit4Engine.E e=new Audit4Engine.E();Class<?> cls=e.cls;
  edt(()->{try{frame=cls.getConstructor().newInstance();}catch(Throwable t){throw new RuntimeException(t);}});
  edt(()->{}); // drain queued initialization callbacks before loading the saved plan
  edt(()->{try{Audit4Engine.meth(cls,"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class).invoke(frame,new File(a[0]),null,null);}catch(Throwable t){throw new RuntimeException(t);}});
  edt(()->{}); // drain load-time callbacks, then capture all values on EDT
  edt(()->{try{in=Audit4Engine.meth(cls,"readInputs").invoke(frame);}catch(Throwable t){throw new RuntimeException(t);}});
  System.out.println("INPUTS\t"+fingerprint(in));
  System.out.println("TAX_YEAR="+Audit4Engine.fld(Class.forName(cls.getName()+"$TaxEngine"),"ACTIVE_TAX_YEAR").get(null));
  edt(()->((JFrame)frame).dispose());
  int solve=Integer.parseInt(a[1]),fan=Integer.parseInt(a[2]),itr=Integer.parseInt(a[3]),threads=Integer.parseInt(a[4]);
  Object r=e.run(in,threads,solve,fan,itr,0);int survived=0;double[][] balances=(double[][])get(r,"fanBalances");for(double[] b:balances)if(b[b.length-1]>0)survived++;
  if(Math.abs(Audit4Engine.dbl(r,"actualPoS")-survived/(double)fan)>1e-12)throw new AssertionError("portfolio survival mismatch");
  System.out.printf(Locale.US,"STABLE\tPoS=%.6f\tHASH=%s\trows=%d\tfirstWd=%d\tMAGI=%d%n",Audit4Engine.dbl(r,"actualPoS"),Audit4Engine.fingerprint(r),e.rows(r).size(),Audit4Engine.integer(e.rows(r).get(0),"wdActual"),Audit4Engine.integer(e.rows(r).get(0),"magi"));
  System.out.println("AUDIT5_STABLE_LOADER_TOTAL PASSED=1 FAILED=0");System.exit(0);
 }
}
