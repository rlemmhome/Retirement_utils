import java.lang.reflect.*;
import java.util.*;
/** Full-engine brokerage gain boundary/control acceptance versus earlier reviewed build. */
public class Audit5PostFixSale {
 static int pass,fail;
 static void ck(String n,boolean yes){System.out.println((yes?"PASS":"FAIL")+"\t"+n);if(yes)pass++;else fail++;}
 static int n(Object r,String key)throws Exception{return Audit4Engine.integer(r,key);}
 static double d(Object r,String key)throws Exception{return Audit4Engine.dbl(r,key);}
 static void s(Object r,String key,Object v)throws Exception{Audit4Engine.set(r,key,v);}
 static String hash(Object r)throws Exception{return Audit4Engine.fingerprint(r);}
 static void run(Audit4Engine.E e,Object base,String name,int proc,int basis,boolean conv,int month,int threads,boolean compare)throws Exception{
  Object i=Audit4Engine.meth(base.getClass(),"copy").invoke(base);
  s(i,"saleProceeds",proc);s(i,"saleBasis",basis);s(i,"convEnabled",conv);
  s(i,"withdrawStartMonth",month);s(i,"priorMagi1",140000);s(i,"priorMagi2",140000);
  s(i,"mmbPaysConvTax",true);
  if(name.contains("flat_conversion")){s(i,"convFillMode",false);s(i,"convFlat",40000);}
  Object r=e.run(i,threads,220,120,15,9001L);
  Object first=e.rows(r).get(0);
  ck(name+" first year's sale proceeds retained in holding account", Math.abs(n(first,"mmbBal")-(proc-n(first,"convTaxFromMmb")))<=2);
  ck(name+" first-year MAGI finite nonnegative",n(first,"magi")>=0);
  ck(name+" first-year preferential gain bands nonnegative",d(first,"pref0")>=0&&d(first,"pref15")>=0&&d(first,"pref20")>=0);
  ck(name+" preferential bands sum no more than realized gain",d(first,"pref0")+d(first,"pref15")+d(first,"pref20")<=Math.max(0,proc-basis)+2);
  ck(name+" first-year tax and NIIT nonnegative",n(first,"tax")>=0&&d(first,"niit")>=0);
  if(name.contains("flat_conversion")){
    ck(name+" flat Roth conversion is actually performed",n(first,"conversion")==40000&&n(first,"convTax")>0);
    ck(name+" brokerage cash pays all conversion tax",Math.abs(n(first,"convTaxFromMmb")-n(first,"convTax"))<=2);
    ck(name+" tax from holding account preserves full gross in Roth",Math.abs(n(first,"convNetToRoth")-n(first,"conversion"))<=2);
    ck(name+" 2027 sale affects 2029 IRMAA",e.rows(r).size()>2&&n(e.rows(r).get(2),"irmaaTier")>0);
  }
  ck(name+" first-year cash flow reconciles",Math.abs(n(first,"totalIncome")-n(first,"totalSpend")-n(first,"surplus"))<=2);
  ck(name+" no negative fan path balances",Arrays.stream((double[][])Audit4Engine.val(r,"fanBalances")).flatMapToDouble(Arrays::stream).allMatch(x->x>=0&&Double.isFinite(x)));
  int seen=0;double[][] bal=(double[][])Audit4Engine.val(r,"fanBalances");for(double[] p:bal)if(p[n(i,"horizon")]>0)seen++;
  ck(name+" independently counted Actual PoS",Math.abs(d(r,"actualPoS")-seen/120.0)<1e-12);
  String digest=hash(r);
  System.out.printf(Locale.US,"SALECASE\t%s\tbase=2027\tproceeds=%d\tbasis=%d\tconv=%b\tmonth=%d\tthreads=%d\tMAGI=%d\twd=%d\ttax=%d\tNIIT=%.2f\tconvGross=%d\tconvTax=%d\tIRMAA=%d\tpref0=%.2f\tpref15=%.2f\tpref20=%.2f\tMM=%d\tMmb=%d\tPoS=%.5f\tHASH=%s%n",name,proc,basis,conv,month,threads,n(first,"magi"),n(first,"wdActual"),n(first,"tax"),d(first,"niit"),n(first,"conversion"),n(first,"convTax"),n(first,"irmaaTier"),d(first,"pref0"),d(first,"pref15"),d(first,"pref20"),n(first,"mmBal"),n(first,"mmbBal"),d(r,"actualPoS"),digest);
  if(compare){Object multi=e.run(i,threads==4?1:4,220,120,15,9001L);ck(name+" single-vs-four fan-path exact parity",digest.equals(hash(multi)));}
 }
 public static void main(String[] a)throws Exception{
  Audit4Engine.E e=new Audit4Engine.E();Object i=Audit5Core.load(e,a[0]);
  ck("2027 scenario activated",((Integer)Audit4Engine.fld(Class.forName(e.cls.getName()+"$TaxEngine"),"ACTIVE_TAX_YEAR").get(null))==2027);
  run(e,i,"no_sale_2027",0,0,false,1,1,true);
  run(e,i,"MFJ_sale_0_15_20",700000,20000,false,1,1,true);
  run(e,i,"July_sale_with_conversion",400000,60000,true,7,4,true);
  run(e,i,"December_sale_with_conversion",400000,60000,true,12,1,true);
  run(e,i,"July_sale_flat_conversion_40000",400000,60000,true,7,1,true);
  run(e,i,"sale_capital_loss",7000,14000,true,7,4,false);
  System.out.printf("AUDIT5_POSTFIX_SALE_TOTAL PASSED=%d FAILED=%d%n",pass,fail);System.exit(fail==0?0:1);
 }
}
