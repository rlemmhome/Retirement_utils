import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.security.*;
import java.nio.*;
import javax.swing.*;
import sun.misc.Unsafe;

/** Audit4 against the actual Java implementation, not a rewritten financial model. */
public class Audit4Engine {
 static int pass=0,fail=0; static Unsafe U;
 static { try { Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);U=(Unsafe)f.get(null);} catch(Exception x){throw new ExceptionInInitializerError(x);} }
 static Field fld(Class<?> c,String name)throws Exception { for(Class<?> p=c;p!=null;p=p.getSuperclass()){try {Field f=p.getDeclaredField(name);f.setAccessible(true);return f;}catch(NoSuchFieldException ignored){}}throw new NoSuchFieldException(name);}
 static Object val(Object o,String name)throws Exception{return fld(o.getClass(),name).get(o);} 
 static double dbl(Object o,String name)throws Exception{return ((Number)val(o,name)).doubleValue();}
 static int integer(Object o,String name)throws Exception{return ((Number)val(o,name)).intValue();}
 static boolean bool(Object o,String name)throws Exception{return (Boolean)val(o,name);}
 static void set(Object o,String name,Object v)throws Exception{fld(o.getClass(),name).set(o,v);}
 static boolean has(Object o,String name){try{fld(o.getClass(),name);return true;}catch(Exception e){return false;}}
 static Method meth(Class<?> c,String name,Class<?>...args)throws Exception{Method m=c.getDeclaredMethod(name,args);m.setAccessible(true);return m;}
 static void check(String name,boolean ok){if(ok){pass++;System.out.println("PASS\t"+name);}else{fail++;System.out.println("FAIL\t"+name);}}
 static void near(String name,double a,double b,double tol){check(name+String.format(Locale.US," (%.4f / %.4f)",a,b),Double.isFinite(a)&&Double.isFinite(b)&&Math.abs(a-b)<=tol);}
 static String fingerprint(Object r)throws Exception{ MessageDigest d=MessageDigest.getInstance("SHA-256");for(String n:new String[]{"fanBalances","fanShort","fanWithdrawals"}){double[][] arr=(double[][])val(r,n);for(double[] a:arr)for(double v:a){long x=Double.doubleToLongBits(v);for(int j=7;j>=0;j--)d.update((byte)(x>>(j*8)));}}byte[] b=d.digest();StringBuilder s=new StringBuilder();for(int i=0;i<8;i++)s.append(String.format("%02x",b[i]));return s.toString();}
 static class E{
  final Class<?> cls,inpCls,proCls;final Object obj;final Method simulate; E()throws Exception {
   cls=Class.forName("com.hiflite.riskbased_optsocsec.RiskBased_OptSocSec_v2");inpCls=Class.forName(cls.getName()+"$SimInputs");proCls=Class.forName(cls.getName()+"$ProResults");obj=U.allocateInstance(cls);
   set(obj,"countsProWork",ThreadLocal.withInitial(()->Boolean.FALSE));set(obj,"simCount",new java.util.concurrent.atomic.AtomicLong());set(obj,"simPathYears",new java.util.concurrent.atomic.AtomicLong());
   simulate=meth(cls,"simulatePro",inpCls,long.class,int.class,int.class,int.class,boolean.class,int.class);
  }
  Object input()throws Exception {Constructor<?> c=inpCls.getDeclaredConstructor();c.setAccessible(true);Object i=c.newInstance();
   set(i,"baseYear",2027);set(i,"horizon",14);set(i,"withdrawStartYear",2027);set(i,"withdrawStartMonth",1);set(i,"manBirthYear",1961);set(i,"manBirthMonth",9);set(i,"womanBirthYear",1962);set(i,"womanBirthMonth",12);set(i,"manPlanAge",75);set(i,"womanPlanAge",76);
   set(i,"manTradIRA",900000);set(i,"manRothIRA",40000);set(i,"womanTradIRA",400000);set(i,"womanRoth401K",40000);set(i,"portfolio",1380000);set(i,"mmPrior",70000);
   set(i,"targetPoS",0.8);set(i,"nomReturn",0.055);set(i,"stdDev",0.108);set(i,"inflation",0.023);set(i,"inflationStdDev",0.0273);set(i,"medInflation",0.045);
   set(i,"livingExp",105000);set(i,"medical",16000);set(i,"computedTax",true);set(i,"convEnabled",true);set(i,"convFillMode",false);set(i,"convFlat",40000);
   set(i,"ssCola",0.024);set(i,"piaAsOfYear",2027);set(i,"bridgeMode",0);set(i,"bridgeDelayedSS",true);set(i,"ssColaTracksInflation",true);
   set(i,"manPIA",3924);set(i,"womanPIA",4037);set(i,"manSSStartYear",2027);set(i,"manSSStartMonth",7);set(i,"womanSSStartYear",2029);set(i,"womanSSStartMonth",6);
   set(i,"manSSMonthly",4000.0);set(i,"womanSSMonthly",4000.0);set(i,"manSSAmount",48000);set(i,"womanSSAmount",48000);
   set(i,"goGoMultiplier",1.7);set(i,"goGoDuration",10);set(i,"slowGoMultiplier",1.3);set(i,"slowGoDuration",4);set(i,"priorMagi1",143000);set(i,"priorMagi2",143000);
   set(i,"proPosUpperGuardrail",0.2);set(i,"proPosLowerGuardrail",0.2);set(i,"hisRmdShare",0.5);set(i,"herRmdShare",0.5);
   return i;
  }
  Object run(Object i,int threads,int solver,int fan,int bins,long seed)throws Exception{try{return simulate.invoke(obj,i,seed,solver,fan,bins,false,threads);}catch(InvocationTargetException e){throw new RuntimeException("sim failed: "+e.getCause(),e.getCause());}}
  Object run(Object i,int threads)throws Exception{return run(i,threads,140,80,12,9001L);}
  List<?> rows(Object r)throws Exception{return (List<?>)val(r,"medianRows");}
  Object row(Object r,int year)throws Exception{return rows(r).get(year);}
 }
 static void audit(E e,String name,Object in,Object r,int fans)throws Exception{
  List<?> rows=e.rows(r);int H=integer(in,"horizon");check(name+" row count",rows.size()==H);
  double[][] fa=(double[][])val(r,"fanBalances"), sh=(double[][])val(r,"fanShort");check(name+" fan paths",fa.length==fans && sh.length==fans);
  int n=0;boolean okay=true;for(int p=0;p<fa.length;p++){ if(fa[p][H]>0)n++;for(double d:fa[p])if(d < -1e-6||!Double.isFinite(d))okay=false;for(double d:sh[p])if(d< -1e-6||!Double.isFinite(d))okay=false; }
  check(name+" balance and shortfall domain",okay);near(name+" portfolio-only POS",dbl(r,"actualPoS"),n/(double)fans,1e-12);
  boolean cash=true,reserve=true; for(Object ro:rows){if(Math.abs(integer(ro,"totalIncome")-integer(ro,"totalSpend")-integer(ro,"surplus"))>2)cash=false;if(integer(ro,"balance")<0||integer(ro,"mmBal")<0||integer(ro,"convTax")<0)reserve=false;if(has(ro,"mmbBal")&&(integer(ro,"mmbBal")<0||integer(ro,"mmbBal")>integer(ro,"mmBal")+2))reserve=false;}
  check(name+" annual cash-flow tieout",cash);check(name+" reserve nonnegative and bounded",reserve);
  Object first=rows.get(0);System.out.printf(Locale.US,"DATA\t%s\tpos=%.6f\twd=%d\tbal=%d\tfirstTax=%d\tmagi=%d\tconv=%d\tctax=%d\tnet=%d\tmm=%d\tmmb=%s\thash=%s%n",name,dbl(r,"actualPoS"),integer(first,"wdActual"),integer(first,"balance"),integer(first,"tax"),integer(first,"magi"),integer(first,"conversion"),integer(first,"convTax"),integer(first,"convNetToRoth"),integer(first,"mmBal"),has(first,"mmbBal")?""+integer(first,"mmbBal"):"NA",fingerprint(r));
 }
 static void sum(E e,String name,Object r)throws Exception{System.out.print("ROWCSV\t"+name);for(Object ro:e.rows(r)){System.out.printf(Locale.US,"\t%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s",integer(ro,"calYear"),integer(ro,"balance"),integer(ro,"wdActual"),integer(ro,"tax"),integer(ro,"magi"),integer(ro,"conversion"),integer(ro,"convTax"),integer(ro,"convNetToRoth"),integer(ro,"mmBal"),integer(ro,"surplus"),integer(ro,"irmaaTier"),has(ro,"mmbBal")?integer(ro,"mmbBal"):"NA",has(ro,"convTaxFromMmb")?integer(ro,"convTaxFromMmb"):"NA");}System.out.println();}
 static void one(E e,String name,Object in)throws Exception{Object r=e.run(in,1);audit(e,name,in,r,80);sum(e,name,r);}
 static void extras(E e)throws Exception{
  Object i=e.input(),base=e.run(i,1);audit(e,"base",i,base,80);sum(e,"base",base);
  Object same=e.run(i,4);check("thread determinism base hash 1/4",fingerprint(base).equals(fingerprint(same)));
  Object split=e.input();set(split,"mmPrior",30000);if(has(split,"mmbPrior"))set(split,"mmbPrior",40000);Object rSplit=e.run(split,1);audit(e,"split_unchecked",split,rSplit,80);sum(e,"split_unchecked",rSplit);
  if(!has(split,"mmbPrior"))return;
  Object pay=e.input();set(pay,"mmPrior",30000);set(pay,"mmbPrior",40000);set(pay,"mmbPaysConvTax",true);Object rPay=e.run(pay,1);audit(e,"split_tax_paid",pay,rPay,80);sum(e,"split_tax_paid",rPay);
  Object roff=e.row(rSplit,0),ron=e.row(rPay,0);
  check("tax financed by MMB is positive",integer(ron,"convTaxFromMmb")>0);
  near("MMB-funded conversion retains full gross in Roth",integer(ron,"convNetToRoth"),integer(ron,"conversion")-integer(ron,"convTax")+integer(ron,"convTaxFromMmb"),2);
  near("MMB outflow equals first-year tax contribution",integer(roff,"mmbBal")-integer(ron,"mmbBal"),integer(ron,"convTaxFromMmb"),1);
  near("ordinary money market protected from conversion tax",integer(roff,"mmBal")-integer(roff,"mmbBal"),integer(ron,"mmBal")-integer(ron,"mmbBal"),1);
  near("conversion gross and its tax unchanged by payer",integer(roff,"conversion"),integer(ron,"conversion"),0);
  near("conversion tax amount unchanged by payer",integer(roff,"convTax"),integer(ron,"convTax"),0);
  Object partial=e.input();set(partial,"mmPrior",30000);set(partial,"mmbPrior",2000);set(partial,"mmbPaysConvTax",true);Object rPartial=e.run(partial,1);audit(e,"partial_funding",partial,rPartial,80);sum(e,"partial_funding",rPartial);
  check("partial tax funding uses no more than available",integer(e.row(rPartial,0),"convTaxFromMmb")<=2000);
  near("partial tax funding takes entire 2k",integer(e.row(rPartial,0),"convTaxFromMmb"),2000,1);
  Object no=e.input();set(no,"mmbPaysConvTax",true);Object rNo=e.run(no,1);check("empty MMB checkbox leaves financial fan paths unchanged",fingerprint(base).equals(fingerprint(rNo)));
  Object sale=e.input();set(sale,"saleProceeds",100000);set(sale,"saleBasis",30000);set(sale,"mmbPaysConvTax",true);Object rSale=e.run(sale,1);audit(e,"sale_plus_conversion",sale,rSale,80);sum(e,"sale_plus_conversion",rSale);
  check("gain in MAGI",integer(e.row(rSale,0),"saleGain")==70000);
  check("sale proceeds enter MMB",integer(e.row(rSale,0),"mmbBal")>50000);
  Object half=e.input();set(half,"withdrawStartMonth",7);set(half,"saleProceeds",100000);set(half,"saleBasis",30000);set(half,"mmbPaysConvTax",true);Object rHalf=e.run(half,1);audit(e,"july_sale_tax",half,rHalf,80);sum(e,"july_sale_tax",rHalf);
  Object early=e.input();set(early,"mmPrior",1000);set(early,"mmbPrior",30000);set(early,"mmCoversEarly",true);set(early,"livingExp",350000);set(early,"medical",20000);Object rEarly=e.run(early,1);audit(e,"early_gap_split",early,rEarly,80);sum(e,"early_gap_split",rEarly);
  check("early reserve drawn",integer(e.row(rEarly,0),"mmDraw")>0);
  check("MMB draws after regular 1k exhausted",integer(e.row(rEarly,0),"mmbBal")<30000);
  Object r4=e.run(pay,4);check("thread determinism payer hash 1/4",fingerprint(rPay).equals(fingerprint(r4)));
  Object off=e.input();set(off,"convEnabled",false);set(off,"mmbPrior",40000);set(off,"mmbPaysConvTax",true);Object rOff=e.run(off,1);audit(e,"conversions_disabled",off,rOff,80);check("conversion disabled means zero conversion tax",e.rows(rOff).stream().allMatch(row->{try{return integer(row,"conversion")==0&&integer(row,"convTax")==0&&integer(row,"convTaxFromMmb")==0;}catch(Exception x){throw new RuntimeException(x);}}));
  Object surv=e.input();set(surv,"mmbPrior",30000);set(surv,"mmbPaysConvTax",true);set(surv,"deathWho",1);set(surv,"deathYear",2032);Object rSurv=e.run(surv,1);audit(e,"survivor+MMB",surv,rSurv,80);check("survivor changes next year",bool(e.row(rSurv,6),"survivorYear")&&!bool(e.row(rSurv,5),"survivorYear"));
  Object sr=e.input();set(sr,"mmbPrior",6000);set(sr,"mmPrior",10000);set(sr,"convEnabled",true);set(sr,"deathWho",2);set(sr,"deathYear",2030);set(sr,"scenarioIndex",4);set(sr,"seqOffset",2);Object s1=e.run(sr,1),s4=e.run(sr,4);check("thread determinism historical+MMB 1/4",fingerprint(s1).equals(fingerprint(s4)));
  System.out.println("END EXTRAS");
 }
 static Object guiScenario(E e,String filepath)throws Exception{
  final Object[] h=new Object[1]; final Throwable[] err=new Throwable[1];
  javax.swing.SwingUtilities.invokeAndWait(()->{try{java.lang.reflect.Constructor<?> c=e.cls.getConstructor();Object app=c.newInstance();
    Method load=meth(e.cls,"loadScenarioFromFile",File.class,JTextField.class,JComboBox.class);
    load.invoke(app,new File(filepath),null,null); h[0]=app;
   }catch(Throwable x){err[0]=x;}});
  if(err[0]!=null)throw new RuntimeException("scenario load error",err[0]);
  Method read=meth(e.cls,"readInputs");Object i=read.invoke(h[0]);
  String pbar=((JProgressBar)val(h[0],"progressBar")).getString();
  System.out.println("SCENARIO_STATUS\t"+pbar);
  check("scenario file loaded without warnings",pbar!=null&&!pbar.contains("Warnings"));
  System.out.printf("SCENARIO_INPUT\tportfolio=%d\thorizon=%d\tstart=%d\tgoGo=%.4f\tslowGo=%.4f\tsolve=1200 fan=600\tnewMMB=%s\n",integer(i,"portfolio"),integer(i,"horizon"),integer(i,"withdrawStartYear"),dbl(i,"goGoMultiplier"),dbl(i,"slowGoMultiplier"),has(i,"mmbPrior")?integer(i,"mmbPrior"):"NA");
  check("file go-go multiplier 1.7",Math.abs(dbl(i,"goGoMultiplier")-1.7)<1e-12);
  check("file slow-go multiplier 1.3",Math.abs(dbl(i,"slowGoMultiplier")-1.3)<1e-12);
  check("file portfolio $1,984,338",integer(i,"portfolio")==1984338);
  if(has(i,"mmbPrior")){
   check("old file MMB carry-in defaults zero",integer(i,"mmbPrior")==0);
   check("old file MMB tax switch defaults off",!bool(i,"mmbPaysConvTax"));
  }
  ((javax.swing.JFrame)h[0]).dispose();
  return i;
 }
 static void scenario(E e,String path,int solve,int fan,int iters)throws Exception{
  Object in=guiScenario(e,path);Object r=e.run(in,1,solve,fan,iters,7221L);audit(e,"provided_scenario",in,r,fan);sum(e,"provided_scenario",r);
  if(solve>=600){Object r4=e.run(in,4,solve,fan,iters,7221L);check("supplied scenario thread parity 1/4",fingerprint(r).equals(fingerprint(r4)));}
 }
 public static void main(String[]args)throws Exception{
  String mode=args.length>0?args[0]:"extra";E e=new E();
  if(mode.equals("extra")) extras(e);
  else if(mode.equals("scenario"))scenario(e,args[1],Integer.parseInt(args[2]),Integer.parseInt(args[3]),Integer.parseInt(args[4]));
  else if(mode.equals("scenario4")){Object in=guiScenario(e,args[1]);Object r=e.run(in,4,Integer.parseInt(args[2]),Integer.parseInt(args[3]),Integer.parseInt(args[4]),7221L);audit(e,"provided_scenario_full",in,r,Integer.parseInt(args[3]));sum(e,"provided_scenario_full",r);}
  else throw new IllegalArgumentException(mode);
  System.out.println("AUDIT4_TOTAL\tPASSED="+pass+"\tFAILED="+fail);
  if(fail>0)System.exit(1);
  System.exit(0); // stop Swing's timer threads from the scenario loader
 }
}
