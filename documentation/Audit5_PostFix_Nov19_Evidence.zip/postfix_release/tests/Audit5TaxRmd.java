import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;
public class Audit5TaxRmd{
 static int pass=0,fail=0;
 static void ck(String s,boolean b){System.out.println((b?"PASS":"FAIL")+"\t"+s);if(b)pass++;else fail++;}
 static double d(Object o,String k)throws Exception{return Audit4Engine.dbl(o,k);}
 static int n(Object o,String k)throws Exception{return Audit4Engine.integer(o,k);}
 static Object v(Object o,String k)throws Exception{return Audit4Engine.val(o,k);}
 static void s(Object o,String k,Object x)throws Exception{Audit4Engine.set(o,k,x);}
 static Object invoke(Class<?> c,String name,Class<?>[] types,Object...args)throws Exception{return Audit4Engine.meth(c,name,types).invoke(null,args);}
 static void baseTaxTest(Audit4Engine.E e)throws Exception{
  Class<?> te=Class.forName(e.cls.getName()+"$TaxEngine"),fs=Class.forName(te.getName()+"$FilingStatus");
  @SuppressWarnings({"rawtypes","unchecked"}) Object joint=Enum.valueOf((Class)fs,"MFJ"),single=Enum.valueOf((Class)fs,"SINGLE");
  ck("2027 engine tax base year",(Integer)Audit4Engine.fld(te,"ACTIVE_TAX_YEAR").get(null)==2027);
  double mfj=(Double)invoke(te,"totalDeduction",new Class[]{boolean.class,boolean.class,double.class,fs},true,true,1.0,joint);
  double sg=(Double)invoke(te,"totalDeduction",new Class[]{boolean.class,boolean.class,double.class,fs},true,false,1.0,single);
  ck("2027 MFJ base+two senior add-ons 36600",Math.abs(mfj-36600)<.001);
  ck("2027 single base+senior 18700",Math.abs(sg-18700)<.001);
  double mfjHalf=(Double)invoke(te,"totalDeduction",new Class[]{boolean.class,boolean.class,double.class,fs},true,false,1.0,joint);
  ck("2027 MFJ one senior add-on 34900",Math.abs(mfjHalf-34900)<.001);
  double tax1=(Double)invoke(te,"fedTax",new Class[]{double.class,double.class,fs},25600d,1d,joint);
  double tax2=(Double)invoke(te,"fedTax",new Class[]{double.class,double.class,fs},104050d,1d,joint);
  ck("2027 MFJ 10pct bracket tax boundary 2560",Math.abs(tax1-2560)<.001);
  ck("2027 MFJ 12pct bracket boundary manually reconstructed",Math.abs(tax2-(2560+(104050-25600)*.12))<.001);
  int t0=(Integer)invoke(te,"irmaaTier",new Class[]{double.class,double.class,fs},224000d,1d,joint);
  int t1=(Integer)invoke(te,"irmaaTier",new Class[]{double.class,double.class,fs},224001d,1d,joint);
  int t2=(Integer)invoke(te,"irmaaTier",new Class[]{double.class,double.class,fs},282001d,1d,joint);
  ck("2027 IRMAA $224k exact cliff no surcharge",t0==0);
  ck("2027 IRMAA $224001 goes tier1",t1==1);
  ck("2027 IRMAA $282001 goes tier2",t2==2);
  double[] sc=(double[])invoke(te,"irmaaSurchargeFor",new Class[]{int.class},2027);
  ck("2027 IRMAA T1 per-person annual arithmetic",Math.abs(sc[1]-(83.70+15.40)*12)<1e-7);
  ck("2027 IRMAA T5 per-person annual arithmetic",Math.abs(sc[5]-(502.40+96.40)*12)<1e-7);
  String sig=(String)invoke(te,"thresholdSignature",new Class[]{ });
  ck("2027 set included in optimizer tax signature",sig.contains(";base=2027"));
 }
 static Object run(Audit4Engine.E e,Object i,String name)throws Exception{
  Object r=e.run(i,4,220,120,13,0L);Object row=e.rows(r).get(0);
  System.out.printf(Locale.US,"CASE\t%s\tconv=%d\ttax=%d\tmagi=%d\tpos=%.5f\tfhash=%s%n",name,n(row,"conversion"),n(row,"tax"),n(row,"magi"),d(r,"actualPoS"),Audit4Engine.fingerprint(r));
  int alive=0;double[][] f=(double[][])v(r,"fanBalances");int H=n(i,"horizon");for(int p=0;p<f.length;p++)if(f[p][H]>0)alive++;
  ck(name+" portfolio PoS matched fan count",Math.abs(d(r,"actualPoS")-alive/120.0)<1e-12);
  for(Object x:e.rows(r))ckIf(name+" yearly cash flow",Math.abs(n(x,"totalIncome")-n(x,"totalSpend")-n(x,"surplus"))<=2);
  return r;
 }
 static boolean rowGood=true;
 static void ckIf(String s,boolean ok){if(!ok){rowGood=false;System.out.println("FAIL\t"+s);fail++;}}
 static void conversionTest(Audit4Engine.E e,Object plan)throws Exception {
  s(plan,"fillIrmaaTierIdx",5);s(plan,"fillBracketIdx",6);s(plan,"convCap",0);
  Object unlimited=run(e,plan,"unlimited");int cv=n(e.rows(unlimited).get(0),"conversion");
  ck("both limits off converts > 1 million",cv>1000000);
  Object limit=Audit4Engine.meth(plan.getClass(),"copy").invoke(plan);s(limit,"convCap",100000);Object capped=run(e,limit,"100k_cap");
  ck("optional conversion cap is exactly 100k",n(e.rows(capped).get(0),"conversion")==100000);
  Object top10=Audit4Engine.meth(plan.getClass(),"copy").invoke(plan);s(top10,"fillBracketIdx",0);Object bound=run(e,top10,"10pct_bracket");
  ck("10pct bracket top binds earlier than unbounded",n(e.rows(bound).get(0),"conversion")<cv);
  Object normal=Audit4Engine.meth(plan.getClass(),"copy").invoke(plan);s(normal,"fillIrmaaTierIdx",0);s(normal,"fillBracketIdx",2);Object restricted=run(e,normal,"standard_22pct");
  ck("2027 standard cliff causes MAGI <= 214000 (buffer)",n(e.rows(restricted).get(0),"magi")<=214000);
  ck("unlimited vs standard is materially different",cv>n(e.rows(restricted).get(0),"conversion"));
 }
 static void rmdTest(Audit4Engine.E e)throws Exception {
  Object i=e.input();s(i,"baseYear",2027);s(i,"horizon",19);s(i,"withdrawStartYear",2027);s(i,"manTradIRA",4600000);s(i,"manRothIRA",0);s(i,"womanTradIRA",0);s(i,"womanRoth401K",0);s(i,"portfolio",4600000);s(i,"mmPrior",0);s(i,"convEnabled",false);s(i,"convFlat",0);s(i,"goGoMultiplier",.1);s(i,"slowGoMultiplier",.1);s(i,"livingExp",12000);s(i,"medical",0);s(i,"manPIA",0);s(i,"womanPIA",0);s(i,"manSSMonthly",0d);s(i,"womanSSMonthly",0d);s(i,"manSSAmount",0);s(i,"womanSSAmount",0);s(i,"bridgeMode",2);s(i,"nomReturn",0.0);s(i,"stdDev",0.0);s(i,"inflation",0.0);s(i,"inflationStdDev",0.0);s(i,"medInflation",0.0);
  Object r=run(e,i,"forced_RMD_case");boolean positive=false,good=true,decompose=true;int years=0;long sumforced=0,sumtax=0;
  for(Object x:e.rows(r)){int fd=n(x,"forcedRmd"),t=n(x,"forcedRmdTax"),comp=n(x,"forcedFed")+n(x,"forcedState")+n(x,"forcedIrmaa");if(fd>0){positive=true;years++;sumforced+=fd;sumtax+=t;}if(fd<0||fd>n(x,"combRmd")+1||t< -2)good=false;if(Math.abs(t-comp)>3)decompose=false;}
  ck("forced RMD actually exercised in high-traditional test",positive&&years>=3);
  ck("forced RMD limited by RMD and tax nonnegative",good);
  ck("forced RMD extra tax decomposes federal+state+IRMAA",decompose);
  ck("forced RMD accumulation and incremental tax positive",sumforced>0&&sumtax>0);
  Object rerun=e.run(i,1,220,120,13,0L);ck("forced RMD one/four thread parity",Audit4Engine.fingerprint(r).equals(Audit4Engine.fingerprint(rerun)));
  System.out.printf("FORCED\tyears=%d\tamount=%d\ttax=%d%n",years,sumforced,sumtax);
 }
 public static void main(String[] args)throws Exception{
  Audit4Engine.E e=new Audit4Engine.E();Object plan=Audit5Core.load(e,args[0]);baseTaxTest(e);conversionTest(e,plan);rmdTest(e);ck("all scenario row cash tieouts",rowGood);
  System.out.printf("AUDIT5_TAX_RMD_TOTAL PASSED=%d FAILED=%d%n",pass,fail);System.exit(fail==0?0:1);
 }
}
