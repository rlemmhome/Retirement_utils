#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p temp/build_post temp/home temp/repro_logs temp/src
cp source/post_fix_Nov18_1747.java temp/src/RiskBased_OptSocSec_v2.java
javac -encoding UTF-8 -d temp/build_post temp/src/RiskBased_OptSocSec_v2.java
javac -cp temp/build_post -d temp/build_post tests/Audit4Engine.java tests/Audit5Core.java tests/Audit5Parity.java tests/Audit5GuiPostFix.java tests/Audit5Dialog.java tests/Audit5TaxRmd.java tests/Audit5Optimizer.java tests/Audit5PostFixTax.java tests/Audit5PostFixGui.java tests/Audit5PostFixSale.java tests/Audit5StableLoader.java
java -Xmx2g -cp temp/build_post Audit5PostFixTax > temp/repro_logs/band_edges.log
xvfb-run -a java -Xmx2g -Duser.home="$PWD/temp/home" -cp temp/build_post Audit5PostFixGui scenario/original.ilscen > temp/repro_logs/year_warning.log
xvfb-run -a java -Xmx2g -Duser.home="$PWD/temp/home" -cp temp/build_post Audit5PostFixSale scenario/explicit_2027.ilscen > temp/repro_logs/sale_engine.log
xvfb-run -a java -Xmx2g -Duser.home="$PWD/temp/home" -cp temp/build_post Audit5TaxRmd scenario/explicit_2027.ilscen > temp/repro_logs/tax_rmd.log
for f in temp/repro_logs/*.log; do
  if grep -Eq '^FAIL[[:space:]]|FAILED=[1-9]' "$f"; then echo "FAIL in $f"; exit 1; fi
  grep -E '^AUDIT5_.*TOTAL' "$f" | tail -1
done
echo 'PASS clean targeted post-fix reproduction'
